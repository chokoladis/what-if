-- MySQL dump 10.13  Distrib 8.0.45, for Linux (aarch64)
--
-- Host: localhost    Database: what_if
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_id` bigint unsigned DEFAULT NULL,
  `level` smallint DEFAULT '0',
  `sort` smallint DEFAULT '100',
  `active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_code_unique` (`code`),
  KEY `categories_file_idx` (`file_id`),
  CONSTRAINT `categories_file_fk` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,3,'aperiam updated','aperiam',59,0,100,1,'2026-01-03 05:58:41','2026-01-03 15:32:35'),(4,NULL,'temporibus','temporibus',25,0,100,1,'2026-01-03 05:58:41','2026-01-03 05:58:41'),(5,6,'vel','vel',27,0,100,1,'2026-01-03 05:58:41','2026-01-03 05:58:41'),(16,NULL,'nam','nam',49,0,100,1,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(17,NULL,'molestias','molestias',51,0,100,1,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(18,NULL,'repudiandae','repudiandae',53,0,100,1,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(19,NULL,'numquam','numquam',55,0,100,1,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(20,NULL,'cumque','cumque',57,0,100,1,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(21,NULL,'Животные','zivotnye',68,0,600,1,'2026-01-29 19:29:48','2026-01-29 19:29:48'),(22,21,'Домашние животные','domasnie-zivotnye',NULL,0,610,1,'2026-01-29 19:30:50','2026-01-29 19:30:50'),(23,21,'Дикие животные','dikie-zivotnye',69,0,620,1,'2026-01-29 19:31:14','2026-01-29 19:31:14'),(24,NULL,'Жилье','zile',70,1,500,1,'2026-01-29 19:41:48','2026-01-29 19:41:48'),(25,24,'Частные дома','castnye-doma',71,2,510,1,'2026-01-29 19:43:22','2026-01-29 19:43:22'),(26,NULL,'Политика','politika',73,0,100,1,'2026-01-29 19:46:55','2026-01-29 19:46:55'),(27,26,'Заговоры','zagovory',75,1,110,1,'2026-01-29 19:49:36','2026-01-29 19:49:36');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_user_votes`
--

DROP TABLE IF EXISTS `comment_user_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_user_votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `votes` tinyint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comment_user_votes_comment_idx` (`comment_id`),
  KEY `comment_user_votes_user_idx` (`user_id`),
  CONSTRAINT `comment_user_votes_comments_fk` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comment_user_votes_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_user_votes`
--

LOCK TABLES `comment_user_votes` WRITE;
/*!40000 ALTER TABLE `comment_user_votes` DISABLE KEYS */;
INSERT INTO `comment_user_votes` VALUES (1,23,4,1,'2026-01-04 06:05:19','2026-01-04 06:05:40'),(2,17,2,1,'2026-01-28 17:05:42','2026-01-28 17:05:42');
/*!40000 ALTER TABLE `comment_user_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_user_idx` (`user_id`),
  CONSTRAINT `comments_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,3,'Дядь, не еби мозги на ночь глядя',1,'2025-11-08 16:47:15','2025-11-08 16:47:15',NULL),(2,3,'Ноздреве, которому, может быть, и познакомятся с ним, но те, которые суждено ему чувствовать всю жизнь. Везде поперек каким бы ни было у места, потому что теперь ты упишешь полбараньего бока с.',1,'2026-01-03 06:12:44','2026-01-03 06:12:44',NULL),(3,1,'Чичиков Ноздреву. — А что же, где ваша девчонка? — Эй, Пелагея! — сказала хозяйка. Чичиков подвинулся к пресному пирогу с яйцом, и, съевши тут же несколько в большем размере. Резные узорочные.',1,'2026-01-03 06:15:29','2026-01-03 06:15:29',NULL),(4,2,'Чичиков и даже по ту сторону, весь этот лес, которым вон — синеет, и все, что ни есть у меня, — душа, смерть люблю тебя! Мижуев, смотри, вот судьба свела: ну что он спорил, а между тем про себя.',0,'2026-01-03 06:15:29','2026-01-03 06:15:29',NULL),(5,1,'Подъезжая ко двору, Чичиков заметил в руках хозяина неизвестно откуда взявшуюся колоду карт. — А вы еще не вычеркнуть из ревизии? — Ну вот уж точно, как будто он хотел вытянуть из него мнение.',1,'2026-01-03 06:15:29','2026-01-03 06:15:29',NULL),(6,1,'Эй, — человек! позови приказчика, он должен быть сегодня здесь. Приказчик явился. Это был среднего роста, очень недурно сложенный молодец с полными румяными щеками, с белыми, как снег, зубами и.',0,'2026-01-03 06:15:29','2026-01-03 06:15:29',NULL),(7,2,'Я уж тебя знал. — Нет, я спросил не для просьб. Впрочем, чтобы успокоить ее, он дал ей медный грош, и она побрела восвояси, уже довольная тем, что станет наконец врать всю жизнь, и выдет просто черт.',1,'2026-01-03 06:15:29','2026-01-03 06:15:29',NULL),(8,3,'Впрочем, хотя эти деревца были не лишены приятности, но в шарманке была одна дудка очень бойкая, никак не будет: или нарежется в буфете таким образом, что только нужно было слушать: — Милушкин.',0,'2026-01-03 06:15:29','2026-01-03 06:15:29',NULL),(9,1,'Манилова ничего не имел у себя над головою, повернуться и опять смягчил выражение, прибавивши: — — Точно, очень многие. — А я к тебе сейчас приду. Нужно только ругнуть подлеца приказчика. Чичиков.',1,'2026-01-03 06:15:29','2026-01-03 06:15:29',NULL),(10,2,'Ноздрев, — такая бестия, подсел к ней и на — уезжавший экипаж. — Вон столбовая дорога! — А вот тут скоро будет и кузница! — сказал Манилов, которому очень — понравилась такая мысль, — как желаете вы.',0,'2026-01-03 06:15:29','2026-01-03 06:15:29',NULL),(11,1,'Отчего ж ты меня почитаешь? — говорил Чичиков, выходя в сени. — А что брат, — говорил Селифан, приподнявшись и хлыснув кнутом ленивца. — Ты знай свое дело, панталонник ты немецкий! Гнедой.',1,'2026-01-03 06:15:29','2026-01-03 06:15:29',NULL),(12,3,'Да как же? Я, право, в толк-то не возьму. Нешто хочешь ты их сам продай, когда уверен, что выиграешь втрое. — Я дивлюсь, как они уже мертвые. «Эк ее, дубинноголовая какая! — сказал Манилов с улыбкою.',1,'2026-01-03 06:15:29','2026-01-03 06:15:29',NULL),(13,1,'Осведомившись в — своих поступках, — присовокупил Манилов с такою точностию, которая показывала более, чем одно простое любопытство. В приемах своих господин имел что-то солидное и высмаркивался.',1,'2026-01-03 06:17:24','2026-01-03 06:17:24',NULL),(14,1,'Это все выдумали доктора немцы да французы, я бы мог выйти очень, очень лакомый кусочек. Это бы скорей походило на диво, если бы соседство было — никак не опрокину. — Затем — начал он слегка.',1,'2026-01-03 06:17:24','2026-01-03 06:17:24',NULL),(15,2,'Прошу прощенья! я, кажется, вас побеспокоил. Пожалуйте, садитесь — сюда! Прошу! — сказал Манилов. — Здесь Ноздрев и Чичиков поцеловались. — И кобылы не нужно. Ну, скажите сами, — на крыльцо со.',1,'2026-01-03 06:17:24','2026-01-03 06:17:24',NULL),(16,3,'Бейте его! — кричал Ноздрев, — принеси-ка щенка! Каков щенок! — — продолжал он, обращаясь к Чичикову, — границу, — где оканчивается моя земля. Ноздрев повел своих гостей полем, которое во многих.',1,'2026-01-03 06:17:24','2026-01-03 06:17:24',NULL),(17,2,'Да чтобы не давал овса лошадям его, — пусть их едят одно сено. Последнего заключения Чичиков никак не назвал души умершими, а только несуществующими. Собакевич слушал все по-прежнему, нагнувши.',1,'2026-01-03 06:17:24','2026-01-03 06:17:24',NULL),(18,3,'Весь следующий день посвящен был визитам; приезжий отправился делать визиты всем городским сановникам. Был с почтением у губернатора, который, как оказалось, подобно Чичикову был ни толст, ни тонок.',0,'2026-01-03 06:17:24','2026-01-03 06:17:24',NULL),(19,1,'Манилов с улыбкою. Хозяйка села за свою суповую чашку; гость был посажен между хозяином и хозяйкою, слуга завязал детям на шею салфетки. — Какие миленькие дети, — сказал Манилов тоже ласково и как.',1,'2026-01-03 06:17:24','2026-01-03 06:17:24',NULL),(20,1,'Барин! ничего не хотите продать, прощайте! — Позвольте, я сяду на стуле. — Позвольте мне вас попросить в мой кабинет, — сказал — Собакевич. — Ты их продашь, тебе на первой ярмарке дадут за них дам.',0,'2026-01-03 06:17:24','2026-01-03 06:17:24',NULL),(21,2,'Он приехал бог знает какое жалованье; другой отхватывал наскоро, как пономарь; промеж них звенел, как почтовый звонок, неугомонный дискант, вероятно молодого щенка, и все помню; ты ее только теперь.',0,'2026-01-03 06:17:24','2026-01-03 06:17:24',NULL),(22,3,'Да зачем мне собаки? я не возьму ее в рукава, схватил в руку черешневый чубук. Чичиков — стал бледен как полотно. Он хотел что-то сказать, но чувствовал, что ему нужно что-то сделать, предложить.',0,'2026-01-03 06:17:24','2026-01-03 06:17:24',NULL),(23,4,'test comments',1,'2026-01-04 04:52:38','2026-01-04 04:52:38',NULL);
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments_replies`
--

DROP TABLE IF EXISTS `comments_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments_replies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_main_id` bigint unsigned NOT NULL,
  `comment_reply_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_replies_comment_main_idx` (`comment_main_id`),
  KEY `comments_replies_comment_reply_idx` (`comment_reply_id`),
  CONSTRAINT `comments_replies_comments_fk_main` FOREIGN KEY (`comment_main_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_replies_comments_fk_reply` FOREIGN KEY (`comment_reply_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments_replies`
--

LOCK TABLES `comments_replies` WRITE;
/*!40000 ALTER TABLE `comments_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expansion` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `relation` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `files_path_unique` (`path`),
  UNIQUE KEY `files_path_thumbnail_unique` (`path_thumbnail`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (1,'VCvEZQmvgfwof4laMluJm1OKjJtzwzwg0VInpoMz.jpg','jpg','VCv/VCvEZQmvgfwof4laMluJm1OKjJtzwzwg0VInpoMz.jpg',NULL,NULL,'questions','2025-11-02 16:33:20','2025-11-02 16:33:20'),(2,'Z6oSYvBNASQ9ESLMAaPAueN84UHjpRzXve9CNtOx.jpg','jpg','Z6o/Z6oSYvBNASQ9ESLMAaPAueN84UHjpRzXve9CNtOx.jpg',NULL,NULL,'questions','2025-11-02 16:33:36','2025-11-02 16:33:36'),(3,'BWwkpq7YPnmgOocRDBXKtcIjxPrhXtBtsDkkwhWV.jpg','jpg','BWw/BWwkpq7YPnmgOocRDBXKtcIjxPrhXtBtsDkkwhWV.jpg',NULL,NULL,'questions','2025-11-02 16:43:34','2025-11-02 16:43:34'),(4,'yl126khSaM5xr2jGGPkyibE1HThaCcYKayKukNoF.jpg','jpg','yl1/yl126khSaM5xr2jGGPkyibE1HThaCcYKayKukNoF.jpg',NULL,NULL,'questions','2025-11-02 16:47:39','2025-11-02 16:47:39'),(5,'c33majR6ZNJJmIi6HvqX6E4b2gRdzZApyoJnHYP8.jpg','jpg','c33/c33majR6ZNJJmIi6HvqX6E4b2gRdzZApyoJnHYP8.jpg',NULL,NULL,'questions','2025-11-02 16:47:51','2025-11-02 16:47:51'),(6,'M5b4KGrVDtSSLRuIyUZmjHk7H3oGvnWaYpvRRs55.jpg','jpg','M5b/M5b4KGrVDtSSLRuIyUZmjHk7H3oGvnWaYpvRRs55.jpg',NULL,NULL,'questions','2025-11-02 16:48:37','2025-11-02 16:48:37'),(7,'YDytUfFtHLunwmDsyhjimNoplYiB0vYW2ApRnxyu.jpg','jpg','YDy/YDytUfFtHLunwmDsyhjimNoplYiB0vYW2ApRnxyu.jpg',NULL,NULL,'questions','2025-11-02 16:50:25','2025-11-02 16:50:25'),(8,'Yr5yNgHr3PYpfR7T57Oxr7tsDKxlJyyMmOaNvVV1.jpg','jpg','Yr5/Yr5yNgHr3PYpfR7T57Oxr7tsDKxlJyyMmOaNvVV1.jpg',NULL,NULL,'questions','2025-11-02 16:50:49','2025-11-02 16:50:49'),(9,'phHAcLajJdZx2cNL154L4xTcKO4MSHWlsqrWfmbn.jpg','jpg','phH/phHAcLajJdZx2cNL154L4xTcKO4MSHWlsqrWfmbn.jpg',NULL,NULL,'questions','2025-11-02 16:52:33','2025-11-02 16:52:33'),(10,'uGdvnsks96Q4p5iEPHPhWbbG4dSfqLZCrbglPLIv.jpg','jpg','uGd/uGdvnsks96Q4p5iEPHPhWbbG4dSfqLZCrbglPLIv.jpg',NULL,NULL,'questions','2025-11-02 16:55:08','2025-11-02 16:55:08'),(11,'DP0zsa746mvVrbcCjjLQtkDMT288w0OAhH0vValn.jpg','jpg','DP0/DP0zsa746mvVrbcCjjLQtkDMT288w0OAhH0vValn.jpg',NULL,NULL,'questions','2025-11-02 16:56:12','2025-11-02 16:56:12'),(12,'gtIAZvqLaySeTy2m87fVtHDIEl6jKhqnLZ5zuSCW.jpg','jpg','gtI/gtIAZvqLaySeTy2m87fVtHDIEl6jKhqnLZ5zuSCW.jpg',NULL,NULL,'questions','2025-11-02 16:57:59','2025-11-02 16:57:59'),(14,'E9gXctJNcxMH1LtEtYZS4h7IFWVOaN8TnrrznzzS.jpg','jpg','E9g/E9gXctJNcxMH1LtEtYZS4h7IFWVOaN8TnrrznzzS.jpg',NULL,NULL,'users','2025-11-08 06:52:51','2025-11-08 06:52:51'),(15,'jBJIzXsZgA7Z8ZrbYenhO7NqYlhFMJVpjPqH6kCi.jpg','jpg','jBJ/jBJIzXsZgA7Z8ZrbYenhO7NqYlhFMJVpjPqH6kCi.jpg',NULL,NULL,'categories','2025-11-08 15:36:26','2025-11-08 15:36:26'),(16,'4cDc1tCeYFN4lBhWjk4kl5NDNoQfR9ffwWchNMKX.jpg','jpg','4cD/4cDc1tCeYFN4lBhWjk4kl5NDNoQfR9ffwWchNMKX.jpg',NULL,NULL,'questions','2025-11-08 16:44:19','2025-11-08 16:44:19'),(17,'6i9iZfCfQLa3D3VhpL847eZyaI7GdT30dJKoKJeA.jpg','jpg','6i9/6i9iZfCfQLa3D3VhpL847eZyaI7GdT30dJKoKJeA.jpg',NULL,NULL,'questions','2025-11-08 16:44:56','2025-11-08 16:44:56'),(18,'qnZ3kZeYv8CVKbXRlsh1cEwQ2vGaf9OiOCPbDchm.gif','gif','qnZ/qnZ3kZeYv8CVKbXRlsh1cEwQ2vGaf9OiOCPbDchm.gif',NULL,NULL,'questions','2025-12-24 08:24:00','2025-12-24 08:24:00'),(19,'c211fe15-782b-3fa9-918e-40a1d7c368b5.jpg','jpg','c21/c211fe15-782b-3fa9-918e-40a1d7c368b5.jpg',NULL,NULL,'categories','2026-01-03 05:58:41','2026-01-03 05:58:41'),(20,'04c5975b-ceaa-3bc2-bcd3-5fe16c2003c7.png','png','04c/04c5975b-ceaa-3bc2-bcd3-5fe16c2003c7.png',NULL,NULL,'questions','2026-01-03 05:58:41','2026-01-03 05:58:41'),(22,'0cdec846-9d24-31db-a0cd-b56026836f59.jpeg','jpeg','0cd/0cdec846-9d24-31db-a0cd-b56026836f59.jpeg',NULL,NULL,'questions','2026-01-03 05:58:41','2026-01-03 05:58:41'),(24,'bb1d0f85-aac2-3f99-8b22-195c12e0f1f1.jpeg','jpeg','bb1/bb1d0f85-aac2-3f99-8b22-195c12e0f1f1.jpeg',NULL,NULL,'questions','2026-01-03 05:58:41','2026-01-03 05:58:41'),(25,'8f77d3a5-14cd-3699-8638-5e605974b80a.jpeg','jpeg','8f7/8f77d3a5-14cd-3699-8638-5e605974b80a.jpeg',NULL,NULL,'categories','2026-01-03 05:58:41','2026-01-03 05:58:41'),(26,'9956155b-a1f6-3671-b9f9-4bfb3555ec19.jpeg','jpeg','995/9956155b-a1f6-3671-b9f9-4bfb3555ec19.jpeg',NULL,NULL,'questions','2026-01-03 05:58:41','2026-01-03 05:58:41'),(27,'53a9758e-e972-33db-b970-0ec554119d31.jpeg','jpeg','53a/53a9758e-e972-33db-b970-0ec554119d31.jpeg',NULL,NULL,'categories','2026-01-03 05:58:41','2026-01-03 05:58:41'),(28,'3fcf6fa9-c5c3-3a73-8b07-716ac7535158.jpg','jpg','3fc/3fcf6fa9-c5c3-3a73-8b07-716ac7535158.jpg',NULL,NULL,'questions','2026-01-03 05:58:41','2026-01-03 05:58:41'),(30,'c9b2dc24-b3b0-3af4-be54-f745df693d8d.jpg','jpg','c9b/c9b2dc24-b3b0-3af4-be54-f745df693d8d.jpg',NULL,NULL,'questions','2026-01-03 05:58:41','2026-01-03 05:58:41'),(32,'9dd47635-258b-344e-9ff1-be0ac7b5bab8.jpg','jpg','9dd/9dd47635-258b-344e-9ff1-be0ac7b5bab8.jpg',NULL,NULL,'questions','2026-01-03 05:58:41','2026-01-03 05:58:41'),(34,'9d78d6d3-bbe9-3f71-b232-72bf3095e908.jpg','jpg','9d7/9d78d6d3-bbe9-3f71-b232-72bf3095e908.jpg',NULL,NULL,'questions','2026-01-03 05:58:41','2026-01-03 05:58:41'),(36,'63acf171-fe01-33b7-94a0-0a2d9a3f4ad1.png','png','63a/63acf171-fe01-33b7-94a0-0a2d9a3f4ad1.png',NULL,NULL,'questions','2026-01-03 05:58:41','2026-01-03 05:58:41'),(38,'48cdc4ba-c8ec-3f04-983f-e6bf0121d05b.jpeg','jpeg','48c/48cdc4ba-c8ec-3f04-983f-e6bf0121d05b.jpeg',NULL,NULL,'questions','2026-01-03 05:58:41','2026-01-03 05:58:41'),(40,'6255d680-2b8c-3ae0-9ee4-3ee7de854408.png','png','625/6255d680-2b8c-3ae0-9ee4-3ee7de854408.png',NULL,NULL,'questions','2026-01-03 06:00:09','2026-01-03 06:00:09'),(42,'4f159915-6cde-3464-bae1-75d0b376b7ce.png','png','4f1/4f159915-6cde-3464-bae1-75d0b376b7ce.png',NULL,NULL,'questions','2026-01-03 06:00:09','2026-01-03 06:00:09'),(44,'1141e6a8-6bf2-3a60-a2bd-a09b4c55055f.png','png','114/1141e6a8-6bf2-3a60-a2bd-a09b4c55055f.png',NULL,NULL,'questions','2026-01-03 06:00:09','2026-01-03 06:00:09'),(46,'12bb67ab-e347-3549-8c5b-0cec7facc8a9.jpeg','jpeg','12b/12bb67ab-e347-3549-8c5b-0cec7facc8a9.jpeg',NULL,NULL,'questions','2026-01-03 06:00:09','2026-01-03 06:00:09'),(48,'96244591-6ff0-3d42-9697-8355e261bf31.jpeg','jpeg','962/96244591-6ff0-3d42-9697-8355e261bf31.jpeg',NULL,NULL,'questions','2026-01-03 06:00:09','2026-01-03 06:00:09'),(49,'36e90cd0-1956-334e-8f2b-ae5d6ef0aa59.png','png','36e/36e90cd0-1956-334e-8f2b-ae5d6ef0aa59.png',NULL,NULL,'categories','2026-01-03 06:00:09','2026-01-03 06:00:09'),(50,'f994ee08-74bb-3d42-a2eb-5b12c62b7fee.png','png','f99/f994ee08-74bb-3d42-a2eb-5b12c62b7fee.png',NULL,NULL,'questions','2026-01-03 06:00:09','2026-01-03 06:00:09'),(51,'c1d14810-232a-3db8-a745-90a5d0a99acb.jpeg','jpeg','c1d/c1d14810-232a-3db8-a745-90a5d0a99acb.jpeg',NULL,NULL,'categories','2026-01-03 06:00:09','2026-01-03 06:00:09'),(52,'bc9beb18-a4e8-3cfa-8952-da7081cf45df.jpg','jpg','bc9/bc9beb18-a4e8-3cfa-8952-da7081cf45df.jpg',NULL,NULL,'questions','2026-01-03 06:00:09','2026-01-03 06:00:09'),(53,'b50d722f-7bca-3c7a-b2e8-b8371df0a70f.jpeg','jpeg','b50/b50d722f-7bca-3c7a-b2e8-b8371df0a70f.jpeg',NULL,NULL,'categories','2026-01-03 06:00:09','2026-01-03 06:00:09'),(54,'b5093209-c8d2-3c53-8b10-1bdd4c0fdbe1.png','png','b50/b5093209-c8d2-3c53-8b10-1bdd4c0fdbe1.png',NULL,NULL,'questions','2026-01-03 06:00:09','2026-01-03 06:00:09'),(55,'34ef2ff4-b15f-3b41-9a54-17f0b294edf7.png','png','34e/34ef2ff4-b15f-3b41-9a54-17f0b294edf7.png',NULL,NULL,'categories','2026-01-03 06:00:09','2026-01-03 06:00:09'),(56,'bcc1c4e4-7dc8-31ce-abf8-160a192a7d33.jpeg','jpeg','bcc/bcc1c4e4-7dc8-31ce-abf8-160a192a7d33.jpeg',NULL,NULL,'questions','2026-01-03 06:00:09','2026-01-03 06:00:09'),(57,'58c041c4-7bd7-3961-8729-13254bceb89b.png','png','58c/58c041c4-7bd7-3961-8729-13254bceb89b.png',NULL,NULL,'categories','2026-01-03 06:00:09','2026-01-03 06:00:09'),(58,'8aa12cfe-d97c-3d92-9c92-1c7c1a4edb16.jpg','jpg','8aa/8aa12cfe-d97c-3d92-9c92-1c7c1a4edb16.jpg',NULL,NULL,'questions','2026-01-03 06:00:09','2026-01-03 06:00:09'),(59,'xOU9WojIs0YTwx2xziDy2VYQKdqVRoYZ0iPpVand.png','png','xOU/xOU9WojIs0YTwx2xziDy2VYQKdqVRoYZ0iPpVand.png',NULL,NULL,'categories','2026-01-03 15:32:25','2026-01-03 15:32:25'),(60,'jB2AuEnP7QD34wY6NQ1nFEQ9nvkZwVcfD9Bs7yxa.png','png','jB2/jB2AuEnP7QD34wY6NQ1nFEQ9nvkZwVcfD9Bs7yxa.png',NULL,NULL,'questions','2026-01-06 11:59:13','2026-01-06 11:59:13'),(61,'IDDGl6VF6cOJ3Oj0YnNuk8WcYcWaYJQlEpxp7K34.png','png','IDD/IDDGl6VF6cOJ3Oj0YnNuk8WcYcWaYJQlEpxp7K34.png',NULL,NULL,'questions','2026-01-20 08:34:50','2026-01-20 08:34:50'),(62,'0BS7JOSqcixbD1uwFW2UGAVpkVknQEnX8XwtSKCL.jpg','jpg','0BS/0BS7JOSqcixbD1uwFW2UGAVpkVknQEnX8XwtSKCL.jpg',NULL,NULL,'questions','2026-01-20 08:39:01','2026-01-20 08:39:01'),(63,'hhrT8ILkv06TtD1Lp0XlZMn3uI4UCRtsNUtYWIU0.jpg','jpg','hhr/hhrT8ILkv06TtD1Lp0XlZMn3uI4UCRtsNUtYWIU0.jpg',NULL,NULL,'questions','2026-01-20 08:40:32','2026-01-20 08:40:32'),(64,'HMhKwjkfdCesw0v69VnP8SlPoopR7NvjzuQu7Tte.jpg','jpg','HMh/HMhKwjkfdCesw0v69VnP8SlPoopR7NvjzuQu7Tte.jpg',NULL,NULL,'questions','2026-01-20 08:45:21','2026-01-20 08:45:21'),(65,'VrgErpJ9dEFy0hlwxsdihniHNQf0XiLh01fcmHnr.jpg','jpg','Vrg/VrgErpJ9dEFy0hlwxsdihniHNQf0XiLh01fcmHnr.jpg',NULL,NULL,'users','2026-01-20 08:45:55','2026-01-20 08:45:55'),(66,'Eiz2NWxEyjT0MDFrjrA1HQiu0vnbpC0lsL1NWnEu.jpg','jpg','Eiz/Eiz2NWxEyjT0MDFrjrA1HQiu0vnbpC0lsL1NWnEu.jpg',NULL,NULL,'users','2026-01-20 08:55:39','2026-01-20 08:55:39'),(67,'34vtJ9Bhhc6m5hJOZIuf78mwAZ7hGZj2vKiBQTbZ.jpg','jpg','34v/34vtJ9Bhhc6m5hJOZIuf78mwAZ7hGZj2vKiBQTbZ.jpg',NULL,NULL,'users','2026-01-20 09:05:34','2026-01-20 09:05:34'),(68,'Z1AYa55aq6sx9I82XXdDXY9dN4dXxkr8kRdaQxf5.avif','avif','Z1A/Z1AYa55aq6sx9I82XXdDXY9dN4dXxkr8kRdaQxf5.avif',NULL,NULL,'categories','2026-01-29 19:29:48','2026-01-29 19:29:48'),(69,'QmKUUzOSPpJV5zea47KDiKTbUrPi7DnELoy76pnh.avif','avif','QmK/QmKUUzOSPpJV5zea47KDiKTbUrPi7DnELoy76pnh.avif',NULL,NULL,'categories','2026-01-29 19:31:14','2026-01-29 19:31:14'),(70,'PPVU6hJQdQBc49plOrwwX76eNmjp1DuzWFDfOUvD.png','png','PPV/PPVU6hJQdQBc49plOrwwX76eNmjp1DuzWFDfOUvD.png',NULL,NULL,'categories','2026-01-29 19:41:48','2026-01-29 19:41:48'),(71,'KNkdrLqH8POSOa5dweKSa0tF4r5dmjscUAKvbB3U.png','png','KNk/KNkdrLqH8POSOa5dweKSa0tF4r5dmjscUAKvbB3U.png',NULL,NULL,'categories','2026-01-29 19:43:22','2026-01-29 19:43:22'),(72,'O2UZG9ZtfijFujePlPLRVZaspghPd6KBEFJ7w3vo.jpg','jpg','O2U/O2UZG9ZtfijFujePlPLRVZaspghPd6KBEFJ7w3vo.jpg',NULL,NULL,'categories','2026-01-29 19:46:02','2026-01-29 19:46:02'),(73,'KrFwTvbgAnQCrQnkCy5eSEAzEJMGvDv5jJMNDhek.jpg','jpg','KrF/KrFwTvbgAnQCrQnkCy5eSEAzEJMGvDv5jJMNDhek.jpg',NULL,NULL,'categories','2026-01-29 19:46:55','2026-01-29 19:46:55'),(74,'tEnAvRdM4jeh0egYjj1XUCXseFfA219cHM4YnohK.webp','webp','tEn/tEnAvRdM4jeh0egYjj1XUCXseFfA219cHM4YnohK.webp',NULL,NULL,'categories','2026-01-29 19:48:50','2026-01-29 19:48:50'),(75,'YCGQhaWi9nIOeKGrP8mldadjVZH4ZjaLtaHIohlv.webp','webp','YCG/YCGQhaWi9nIOeKGrP8mldadjVZH4ZjaLtaHIohlv.webp',NULL,NULL,'categories','2026-01-29 19:49:36','2026-01-29 19:49:36');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(14,'0001_01_01_000001_create_cache_table',2),(15,'2024_04_14_153225_create_comments_table',2),(16,'2024_04_14_155757_create_comment_user_statuses_table',2),(18,'2024_04_15_074360_create_files_table',2),(22,'2024_04_15_081643_create_question_user_statuses_table',2),(28,'2024_04_14_155757_create_comment_user_votes_table',3),(29,'2024_04_15_074400_create_categories_table',3),(30,'2024_04_15_075201_create_questions_table',3),(31,'2024_04_15_080658_create_question_statistics_table',3),(32,'2024_04_15_081643_create_question_user_votes_table',3),(33,'2024_04_15_101921_create_question_comments_table',3),(34,'2024_06_20_115018_create_user_comments_table',3),(35,'2024_07_08_081554_create_feedback_table',3),(36,'2025_11_02_100258_create_settings_table',4),(37,'2024_04_14_165704_create_comments_replies_table',5),(38,'2024_04_15_081643_create_question_votes_table',6),(40,'2026_01_07_135059_create_tags_table',7),(41,'2026_01_08_121505_create_question_tags_table',8),(42,'2026_01_21_104615_create_user_tags_table',9);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_comments`
--

DROP TABLE IF EXISTS `question_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint unsigned NOT NULL,
  `comment_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_comments_question_idx` (`question_id`),
  KEY `question_comments_comment_idx` (`comment_id`),
  CONSTRAINT `question_comments_comment_fk` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `question_comments_question_fk` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_comments`
--

LOCK TABLES `question_comments` WRITE;
/*!40000 ALTER TABLE `question_comments` DISABLE KEYS */;
INSERT INTO `question_comments` VALUES (1,9,3,'2026-01-03 06:15:29','2026-01-03 06:15:29'),(2,8,4,'2026-01-03 06:15:29','2026-01-03 06:15:29'),(3,7,5,'2026-01-03 06:15:29','2026-01-03 06:15:29'),(4,9,6,'2026-01-03 06:15:29','2026-01-03 06:15:29'),(5,5,7,'2026-01-03 06:15:29','2026-01-03 06:15:29'),(6,9,8,'2026-01-03 06:15:29','2026-01-03 06:15:29'),(7,9,9,'2026-01-03 06:15:29','2026-01-03 06:15:29'),(9,5,11,'2026-01-03 06:15:29','2026-01-03 06:15:29'),(10,9,12,'2026-01-03 06:15:29','2026-01-03 06:15:29'),(11,11,13,'2026-01-03 06:17:24','2026-01-03 06:17:24'),(12,8,14,'2026-01-03 06:17:24','2026-01-03 06:17:24'),(14,8,16,'2026-01-03 06:17:24','2026-01-03 06:17:24'),(15,1,17,'2026-01-03 06:17:24','2026-01-03 06:17:24'),(16,8,18,'2026-01-03 06:17:24','2026-01-03 06:17:24'),(17,5,19,'2026-01-03 06:17:24','2026-01-03 06:17:24');
/*!40000 ALTER TABLE `question_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_statistics`
--

DROP TABLE IF EXISTS `question_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_statistics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint unsigned NOT NULL,
  `views` bigint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_statistics_question_idx` (`question_id`),
  CONSTRAINT `question_statistics_question_fk` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_statistics`
--

LOCK TABLES `question_statistics` WRITE;
/*!40000 ALTER TABLE `question_statistics` DISABLE KEYS */;
INSERT INTO `question_statistics` VALUES (1,1,7,'2025-12-24 08:24:00','2026-01-29 19:12:55'),(5,5,4,'2026-01-03 06:00:09','2026-01-07 06:31:27'),(7,7,1,'2026-01-03 06:00:09','2026-01-03 08:10:48'),(8,8,2,'2026-01-03 06:00:09','2026-01-06 08:25:16'),(9,9,0,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(10,10,1,'2026-01-03 06:00:09','2026-01-03 09:12:36'),(11,11,0,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(14,14,0,'2026-01-08 07:49:47','2026-01-08 07:49:47'),(15,15,0,'2026-01-08 07:51:23','2026-01-08 07:51:23'),(16,16,1,'2026-01-08 07:52:21','2026-01-28 08:00:03'),(17,17,0,'2026-01-08 07:53:18','2026-01-08 07:53:18'),(18,18,1,'2026-01-08 07:53:55','2026-01-28 07:59:51'),(20,20,1,'2026-01-20 08:40:32','2026-01-28 07:59:55'),(21,21,0,'2026-01-20 08:45:21','2026-01-20 08:45:21');
/*!40000 ALTER TABLE `question_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_tags`
--

DROP TABLE IF EXISTS `question_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_tags_question_id_index` (`question_id`),
  KEY `question_tags_tag_id_index` (`tag_id`),
  CONSTRAINT `question_tags_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `question_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_tags`
--

LOCK TABLES `question_tags` WRITE;
/*!40000 ALTER TABLE `question_tags` DISABLE KEYS */;
INSERT INTO `question_tags` VALUES (1,17,1,'2026-01-08 07:53:18','2026-01-08 07:53:18'),(2,17,3,'2026-01-08 07:53:18','2026-01-08 07:53:18'),(3,17,5,'2026-01-08 07:53:18','2026-01-08 07:53:18'),(4,18,3,'2026-01-08 07:53:55','2026-01-08 07:53:55'),(5,18,4,'2026-01-08 07:53:56','2026-01-08 07:53:56'),(6,18,5,'2026-01-08 07:53:56','2026-01-08 07:53:56'),(7,21,4,'2026-01-20 08:45:21','2026-01-20 08:45:21');
/*!40000 ALTER TABLE `question_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_user_votes`
--

DROP TABLE IF EXISTS `question_user_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_user_votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `vote` tinyint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_user_votes_question_idx` (`question_id`),
  KEY `question_user_votes_user_idx` (`user_id`),
  CONSTRAINT `question_user_votes_question_fk` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `question_user_votes_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_user_votes`
--

LOCK TABLES `question_user_votes` WRITE;
/*!40000 ALTER TABLE `question_user_votes` DISABLE KEYS */;
INSERT INTO `question_user_votes` VALUES (3,11,3,-1,'2026-01-03 06:17:24','2026-01-03 06:17:24'),(4,11,3,-1,'2026-01-03 06:17:24','2026-01-03 06:17:24'),(6,7,2,-1,'2026-01-03 06:17:24','2026-01-03 06:17:24'),(7,5,1,-1,'2026-01-03 06:17:24','2026-01-03 06:17:24'),(9,11,1,1,'2026-01-03 06:17:24','2026-01-03 06:17:24'),(11,5,3,1,'2026-01-06 11:17:06','2026-01-06 11:17:06');
/*!40000 ALTER TABLE `question_user_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_votes`
--

DROP TABLE IF EXISTS `question_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `vote` tinyint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_user_votes_question_idx` (`question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_votes`
--

LOCK TABLES `question_votes` WRITE;
/*!40000 ALTER TABLE `question_votes` DISABLE KEYS */;
INSERT INTO `question_votes` VALUES (1,1,2,1,'2026-01-28 16:51:22','2026-01-28 16:51:22');
/*!40000 ALTER TABLE `question_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `file_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `right_comment_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `questions_code_unique` (`code`),
  KEY `questions_user_idx` (`user_id`),
  KEY `questions_category_idx` (`category_id`),
  KEY `questions_file_idx` (`file_id`),
  KEY `questions_title_idx` (`title`),
  KEY `questions_right_comment_idx` (`right_comment_id`),
  CONSTRAINT `questions_category_fk` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `questions_comment_fk` FOREIGN KEY (`right_comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `questions_file_fk` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE,
  CONSTRAINT `questions_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1,3,1,18,'Тестовый вопрос','testovyi-vopros',1,NULL,'2025-12-24 08:24:00','2025-12-24 08:24:00'),(5,1,1,46,'Et ut enim eum incidunt.','et-ut-enim-eum-incidunt',1,7,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(7,1,16,50,'Quibusdam commodi impedit eum eos.','quibusdam-commodi-impedit-eum-eos',1,NULL,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(8,3,17,52,'Inventore nulla ea nihil sed.','inventore-nulla-ea-nihil-sed',1,NULL,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(9,1,18,54,'Reiciendis quo velit officiis velit et debitis sit.','reiciendis-quo-velit-officiis-velit-et-debitis-sit',0,NULL,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(10,3,19,56,'Magni voluptas deleniti nam consectetur.','magni-voluptas-deleniti-nam-consectetur',1,NULL,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(11,1,20,58,'Sapiente aut maxime autem.','sapiente-aut-maxime-autem',0,NULL,'2026-01-03 06:00:09','2026-01-03 06:00:09'),(14,2,5,NULL,'ахуительный котеночек есть такое аниме?','axuitelnyi-kotenocek-est-takoe-anime',1,NULL,'2026-01-08 07:49:47','2026-01-08 07:49:47'),(15,2,NULL,NULL,'ахуительный котенок есть такое аниме?','axuitelnyi-kotenok-est-takoe-anime',1,NULL,'2026-01-08 07:51:23','2026-01-08 07:51:23'),(16,2,NULL,NULL,'ахуитительный котеночек есть такое аниме?','axuititelnyi-kotenocek-est-takoe-anime',1,NULL,'2026-01-08 07:52:21','2026-01-08 07:52:21'),(17,2,NULL,NULL,'Тест тегов','test-tegov',1,NULL,'2026-01-08 07:53:18','2026-01-08 07:53:18'),(18,2,NULL,NULL,'тест тегов повторный','test-tegov-povtornyi',1,NULL,'2026-01-08 07:53:55','2026-01-08 07:53:55'),(20,2,5,63,'test pic 2','test-pic-2',1,NULL,'2026-01-20 08:40:32','2026-01-20 08:40:32'),(21,2,16,64,'testtt','testtt',1,NULL,'2026-01-20 08:45:21','2026-01-20 08:45:21');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `area` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'main',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'main','captcha_set_on','false','2026-01-08 07:27:52','2026-01-08 07:27:52'),(2,'integration','gemini_validate_user_photos','true','2026-01-20 08:38:40','2026-01-20 08:38:40');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort` smallint NOT NULL DEFAULT '300',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (1,'Аниме',300),(2,'Горы',300),(3,'Кошки',300),(4,'Природа',300),(5,'Компьютеры',300),(6,'Разработка',10),(7,'ИИ',100),(8,'Старушки/Деды',500);
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_comments`
--

DROP TABLE IF EXISTS `user_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned NOT NULL,
  `comment_id` bigint unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_comments_user_idx` (`user_id`),
  KEY `user_comments_comment_idx` (`comment_id`),
  CONSTRAINT `user_comments_comment_fk` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_comments_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_comments`
--

LOCK TABLES `user_comments` WRITE;
/*!40000 ALTER TABLE `user_comments` DISABLE KEYS */;
INSERT INTO `user_comments` VALUES (1,'2026-01-03 06:15:29','2026-01-03 06:15:29',1,3,NULL),(2,'2026-01-03 06:15:29','2026-01-03 06:15:29',2,4,NULL),(3,'2026-01-03 06:15:29','2026-01-03 06:15:29',1,5,NULL),(4,'2026-01-03 06:15:29','2026-01-03 06:15:29',1,6,NULL),(5,'2026-01-03 06:15:29','2026-01-03 06:15:29',2,7,NULL),(6,'2026-01-03 06:15:29','2026-01-03 06:15:29',3,8,NULL),(7,'2026-01-03 06:15:29','2026-01-03 06:15:29',1,9,NULL),(8,'2026-01-03 06:15:29','2026-01-03 06:15:29',2,10,NULL),(9,'2026-01-03 06:15:29','2026-01-03 06:15:29',1,11,NULL),(10,'2026-01-03 06:15:29','2026-01-03 06:15:29',3,12,NULL),(11,'2026-01-03 06:17:24','2026-01-03 06:17:24',1,13,NULL),(12,'2026-01-03 06:17:24','2026-01-03 06:17:24',1,14,NULL),(13,'2026-01-03 06:17:24','2026-01-03 06:17:24',2,15,NULL),(14,'2026-01-03 06:17:24','2026-01-03 06:17:24',3,16,NULL),(15,'2026-01-03 06:17:24','2026-01-03 06:17:24',2,17,NULL),(16,'2026-01-03 06:17:24','2026-01-03 06:17:24',3,18,NULL),(17,'2026-01-03 06:17:24','2026-01-03 06:17:24',1,19,NULL),(18,'2026-01-03 06:17:24','2026-01-03 06:17:24',1,20,NULL),(19,'2026-01-03 06:17:24','2026-01-03 06:17:24',2,21,NULL),(20,'2026-01-03 06:17:24','2026-01-03 06:17:24',3,22,NULL),(21,'2026-01-04 04:52:38','2026-01-04 04:52:38',4,23,NULL);
/*!40000 ALTER TABLE `user_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_tags`
--

DROP TABLE IF EXISTS `user_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_tags_user_id_index` (`user_id`),
  KEY `user_tags_tag_id_index` (`tag_id`),
  CONSTRAINT `user_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_tags`
--

LOCK TABLES `user_tags` WRITE;
/*!40000 ALTER TABLE `user_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `photo_id` bigint unsigned DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_photo_idx` (`photo_id`),
  CONSTRAINT `users_files_fk` FOREIGN KEY (`photo_id`) REFERENCES `files` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Test User','user',0,NULL,'test@example.com','2025-10-26 14:38:22','$2y$12$I501fpzvXnYqF4tNawwHeOrB22no0JyuyzkFFURXLr0d3rFThvW/S','FccnBfupeO','2025-10-26 14:38:22','2025-10-26 14:38:22'),(2,'igor2_updated2','admin',0,14,'gustavforeli@gmail.com',NULL,'$2y$12$CivqebVgE6C/yHNc0HRjq.I.G/07MP8tSMldzU2Mtz6GA5QDDngXC',NULL,'2025-10-26 14:48:38','2026-01-28 07:49:30'),(3,'Игорь Шоколад','user',0,NULL,'KorovaDlyaOvec@yandex.ru',NULL,'$2y$12$5WuliccO0K.HjLmi.FN5muevZyPDpqfrICw1XSOuTvund4YZo.A06',NULL,'2025-11-03 15:11:32','2025-11-03 15:11:32'),(4,'testmail','user',0,NULL,'testmail@mail.ru',NULL,'$2y$12$ruA1UrxgcLc0jz1dNSdAP.xjoRciTOwFQd9ppf9p1zsG8dMbVuacq',NULL,'2026-01-04 04:52:21','2026-01-04 04:52:21');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-29 20:31:40
