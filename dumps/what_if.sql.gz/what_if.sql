-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:8889
-- Время создания: Янв 23 2026 г., 12:23
-- Версия сервера: 8.0.40
-- Версия PHP: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `what_if`
--

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id` bigint UNSIGNED NOT NULL,
  `parent_id` bigint UNSIGNED DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_id` bigint UNSIGNED DEFAULT NULL,
  `level` smallint DEFAULT '0',
  `sort` smallint DEFAULT '100',
  `active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `title`, `code`, `file_id`, `level`, `sort`, `active`, `created_at`, `updated_at`) VALUES
(1, 3, 'aperiam updated', 'aperiam', 59, 0, 100, 1, '2026-01-03 05:58:41', '2026-01-03 15:32:35'),
(2, NULL, 'et', 'et', 21, 0, 100, 1, '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(3, 4, 'tempora', 'tempora', 23, 0, 100, 1, '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(4, NULL, 'temporibus', 'temporibus', 25, 0, 100, 1, '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(5, 6, 'vel', 'vel', 27, 0, 100, 1, '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(6, NULL, 'omnis', 'omnis', 29, 0, 100, 1, '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(7, 4, 'voluptas', 'voluptas', 31, 0, 100, 1, '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(8, 4, 'enim', 'enim', 33, 0, 100, 1, '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(9, 4, 'sed', 'sed', 35, 0, 100, 1, '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(10, NULL, 'harum', 'harum', 37, 0, 100, 1, '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(11, NULL, 'atque', 'atque', 39, 0, 100, 1, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(12, NULL, 'qui', 'qui', 41, 0, 100, 1, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(13, NULL, 'voluptatum', 'voluptatum', 43, 0, 100, 1, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(14, NULL, 'saepe', 'saepe', 45, 0, 100, 1, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(15, NULL, 'animi', 'animi', 47, 0, 100, 1, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(16, NULL, 'nam', 'nam', 49, 0, 100, 1, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(17, NULL, 'molestias', 'molestias', 51, 0, 100, 1, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(18, NULL, 'repudiandae', 'repudiandae', 53, 0, 100, 1, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(19, NULL, 'numquam', 'numquam', 55, 0, 100, 1, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(20, NULL, 'cumque', 'cumque', 57, 0, 100, 1, '2026-01-03 06:00:09', '2026-01-03 06:00:09');

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `text`, `active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 3, 'Дядь, не еби мозги на ночь глядя', 1, '2025-11-08 16:47:15', '2025-11-08 16:47:15', NULL),
(2, 3, 'Ноздреве, которому, может быть, и познакомятся с ним, но те, которые суждено ему чувствовать всю жизнь. Везде поперек каким бы ни было у места, потому что теперь ты упишешь полбараньего бока с.', 1, '2026-01-03 06:12:44', '2026-01-03 06:12:44', NULL),
(3, 1, 'Чичиков Ноздреву. — А что же, где ваша девчонка? — Эй, Пелагея! — сказала хозяйка. Чичиков подвинулся к пресному пирогу с яйцом, и, съевши тут же несколько в большем размере. Резные узорочные.', 1, '2026-01-03 06:15:29', '2026-01-03 06:15:29', NULL),
(4, 2, 'Чичиков и даже по ту сторону, весь этот лес, которым вон — синеет, и все, что ни есть у меня, — душа, смерть люблю тебя! Мижуев, смотри, вот судьба свела: ну что он спорил, а между тем про себя.', 0, '2026-01-03 06:15:29', '2026-01-03 06:15:29', NULL),
(5, 1, 'Подъезжая ко двору, Чичиков заметил в руках хозяина неизвестно откуда взявшуюся колоду карт. — А вы еще не вычеркнуть из ревизии? — Ну вот уж точно, как будто он хотел вытянуть из него мнение.', 1, '2026-01-03 06:15:29', '2026-01-03 06:15:29', NULL),
(6, 1, 'Эй, — человек! позови приказчика, он должен быть сегодня здесь. Приказчик явился. Это был среднего роста, очень недурно сложенный молодец с полными румяными щеками, с белыми, как снег, зубами и.', 0, '2026-01-03 06:15:29', '2026-01-03 06:15:29', NULL),
(7, 2, 'Я уж тебя знал. — Нет, я спросил не для просьб. Впрочем, чтобы успокоить ее, он дал ей медный грош, и она побрела восвояси, уже довольная тем, что станет наконец врать всю жизнь, и выдет просто черт.', 1, '2026-01-03 06:15:29', '2026-01-03 06:15:29', NULL),
(8, 3, 'Впрочем, хотя эти деревца были не лишены приятности, но в шарманке была одна дудка очень бойкая, никак не будет: или нарежется в буфете таким образом, что только нужно было слушать: — Милушкин.', 0, '2026-01-03 06:15:29', '2026-01-03 06:15:29', NULL),
(9, 1, 'Манилова ничего не имел у себя над головою, повернуться и опять смягчил выражение, прибавивши: — — Точно, очень многие. — А я к тебе сейчас приду. Нужно только ругнуть подлеца приказчика. Чичиков.', 1, '2026-01-03 06:15:29', '2026-01-03 06:15:29', NULL),
(10, 2, 'Ноздрев, — такая бестия, подсел к ней и на — уезжавший экипаж. — Вон столбовая дорога! — А вот тут скоро будет и кузница! — сказал Манилов, которому очень — понравилась такая мысль, — как желаете вы.', 0, '2026-01-03 06:15:29', '2026-01-03 06:15:29', NULL),
(11, 1, 'Отчего ж ты меня почитаешь? — говорил Чичиков, выходя в сени. — А что брат, — говорил Селифан, приподнявшись и хлыснув кнутом ленивца. — Ты знай свое дело, панталонник ты немецкий! Гнедой.', 1, '2026-01-03 06:15:29', '2026-01-03 06:15:29', NULL),
(12, 3, 'Да как же? Я, право, в толк-то не возьму. Нешто хочешь ты их сам продай, когда уверен, что выиграешь втрое. — Я дивлюсь, как они уже мертвые. «Эк ее, дубинноголовая какая! — сказал Манилов с улыбкою.', 1, '2026-01-03 06:15:29', '2026-01-03 06:15:29', NULL),
(13, 1, 'Осведомившись в — своих поступках, — присовокупил Манилов с такою точностию, которая показывала более, чем одно простое любопытство. В приемах своих господин имел что-то солидное и высмаркивался.', 1, '2026-01-03 06:17:24', '2026-01-03 06:17:24', NULL),
(14, 1, 'Это все выдумали доктора немцы да французы, я бы мог выйти очень, очень лакомый кусочек. Это бы скорей походило на диво, если бы соседство было — никак не опрокину. — Затем — начал он слегка.', 1, '2026-01-03 06:17:24', '2026-01-03 06:17:24', NULL),
(15, 2, 'Прошу прощенья! я, кажется, вас побеспокоил. Пожалуйте, садитесь — сюда! Прошу! — сказал Манилов. — Здесь Ноздрев и Чичиков поцеловались. — И кобылы не нужно. Ну, скажите сами, — на крыльцо со.', 1, '2026-01-03 06:17:24', '2026-01-03 06:17:24', NULL),
(16, 3, 'Бейте его! — кричал Ноздрев, — принеси-ка щенка! Каков щенок! — — продолжал он, обращаясь к Чичикову, — границу, — где оканчивается моя земля. Ноздрев повел своих гостей полем, которое во многих.', 1, '2026-01-03 06:17:24', '2026-01-03 06:17:24', NULL),
(17, 2, 'Да чтобы не давал овса лошадям его, — пусть их едят одно сено. Последнего заключения Чичиков никак не назвал души умершими, а только несуществующими. Собакевич слушал все по-прежнему, нагнувши.', 1, '2026-01-03 06:17:24', '2026-01-03 06:17:24', NULL),
(18, 3, 'Весь следующий день посвящен был визитам; приезжий отправился делать визиты всем городским сановникам. Был с почтением у губернатора, который, как оказалось, подобно Чичикову был ни толст, ни тонок.', 0, '2026-01-03 06:17:24', '2026-01-03 06:17:24', NULL),
(19, 1, 'Манилов с улыбкою. Хозяйка села за свою суповую чашку; гость был посажен между хозяином и хозяйкою, слуга завязал детям на шею салфетки. — Какие миленькие дети, — сказал Манилов тоже ласково и как.', 1, '2026-01-03 06:17:24', '2026-01-03 06:17:24', NULL),
(20, 1, 'Барин! ничего не хотите продать, прощайте! — Позвольте, я сяду на стуле. — Позвольте мне вас попросить в мой кабинет, — сказал — Собакевич. — Ты их продашь, тебе на первой ярмарке дадут за них дам.', 0, '2026-01-03 06:17:24', '2026-01-03 06:17:24', NULL),
(21, 2, 'Он приехал бог знает какое жалованье; другой отхватывал наскоро, как пономарь; промеж них звенел, как почтовый звонок, неугомонный дискант, вероятно молодого щенка, и все помню; ты ее только теперь.', 0, '2026-01-03 06:17:24', '2026-01-03 06:17:24', NULL),
(22, 3, 'Да зачем мне собаки? я не возьму ее в рукава, схватил в руку черешневый чубук. Чичиков — стал бледен как полотно. Он хотел что-то сказать, но чувствовал, что ему нужно что-то сделать, предложить.', 0, '2026-01-03 06:17:24', '2026-01-03 06:17:24', NULL),
(23, 4, 'test comments', 1, '2026-01-04 04:52:38', '2026-01-04 04:52:38', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `comments_replies`
--

CREATE TABLE `comments_replies` (
  `id` bigint UNSIGNED NOT NULL,
  `comment_main_id` bigint UNSIGNED NOT NULL,
  `comment_reply_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `comment_user_votes`
--

CREATE TABLE `comment_user_votes` (
  `id` bigint UNSIGNED NOT NULL,
  `comment_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `votes` tinyint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `comment_user_votes`
--

INSERT INTO `comment_user_votes` (`id`, `comment_id`, `user_id`, `votes`, `created_at`, `updated_at`) VALUES
(1, 23, 4, 1, '2026-01-04 06:05:19', '2026-01-04 06:05:40');

-- --------------------------------------------------------

--
-- Структура таблицы `feedback`
--

CREATE TABLE `feedback` (
  `id` bigint UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `files`
--

CREATE TABLE `files` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expansion` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `relation` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `files`
--

INSERT INTO `files` (`id`, `name`, `expansion`, `path`, `path_thumbnail`, `description`, `relation`, `created_at`, `updated_at`) VALUES
(1, 'VCvEZQmvgfwof4laMluJm1OKjJtzwzwg0VInpoMz.jpg', 'jpg', 'VCv/VCvEZQmvgfwof4laMluJm1OKjJtzwzwg0VInpoMz.jpg', NULL, NULL, 'questions', '2025-11-02 16:33:20', '2025-11-02 16:33:20'),
(2, 'Z6oSYvBNASQ9ESLMAaPAueN84UHjpRzXve9CNtOx.jpg', 'jpg', 'Z6o/Z6oSYvBNASQ9ESLMAaPAueN84UHjpRzXve9CNtOx.jpg', NULL, NULL, 'questions', '2025-11-02 16:33:36', '2025-11-02 16:33:36'),
(3, 'BWwkpq7YPnmgOocRDBXKtcIjxPrhXtBtsDkkwhWV.jpg', 'jpg', 'BWw/BWwkpq7YPnmgOocRDBXKtcIjxPrhXtBtsDkkwhWV.jpg', NULL, NULL, 'questions', '2025-11-02 16:43:34', '2025-11-02 16:43:34'),
(4, 'yl126khSaM5xr2jGGPkyibE1HThaCcYKayKukNoF.jpg', 'jpg', 'yl1/yl126khSaM5xr2jGGPkyibE1HThaCcYKayKukNoF.jpg', NULL, NULL, 'questions', '2025-11-02 16:47:39', '2025-11-02 16:47:39'),
(5, 'c33majR6ZNJJmIi6HvqX6E4b2gRdzZApyoJnHYP8.jpg', 'jpg', 'c33/c33majR6ZNJJmIi6HvqX6E4b2gRdzZApyoJnHYP8.jpg', NULL, NULL, 'questions', '2025-11-02 16:47:51', '2025-11-02 16:47:51'),
(6, 'M5b4KGrVDtSSLRuIyUZmjHk7H3oGvnWaYpvRRs55.jpg', 'jpg', 'M5b/M5b4KGrVDtSSLRuIyUZmjHk7H3oGvnWaYpvRRs55.jpg', NULL, NULL, 'questions', '2025-11-02 16:48:37', '2025-11-02 16:48:37'),
(7, 'YDytUfFtHLunwmDsyhjimNoplYiB0vYW2ApRnxyu.jpg', 'jpg', 'YDy/YDytUfFtHLunwmDsyhjimNoplYiB0vYW2ApRnxyu.jpg', NULL, NULL, 'questions', '2025-11-02 16:50:25', '2025-11-02 16:50:25'),
(8, 'Yr5yNgHr3PYpfR7T57Oxr7tsDKxlJyyMmOaNvVV1.jpg', 'jpg', 'Yr5/Yr5yNgHr3PYpfR7T57Oxr7tsDKxlJyyMmOaNvVV1.jpg', NULL, NULL, 'questions', '2025-11-02 16:50:49', '2025-11-02 16:50:49'),
(9, 'phHAcLajJdZx2cNL154L4xTcKO4MSHWlsqrWfmbn.jpg', 'jpg', 'phH/phHAcLajJdZx2cNL154L4xTcKO4MSHWlsqrWfmbn.jpg', NULL, NULL, 'questions', '2025-11-02 16:52:33', '2025-11-02 16:52:33'),
(10, 'uGdvnsks96Q4p5iEPHPhWbbG4dSfqLZCrbglPLIv.jpg', 'jpg', 'uGd/uGdvnsks96Q4p5iEPHPhWbbG4dSfqLZCrbglPLIv.jpg', NULL, NULL, 'questions', '2025-11-02 16:55:08', '2025-11-02 16:55:08'),
(11, 'DP0zsa746mvVrbcCjjLQtkDMT288w0OAhH0vValn.jpg', 'jpg', 'DP0/DP0zsa746mvVrbcCjjLQtkDMT288w0OAhH0vValn.jpg', NULL, NULL, 'questions', '2025-11-02 16:56:12', '2025-11-02 16:56:12'),
(12, 'gtIAZvqLaySeTy2m87fVtHDIEl6jKhqnLZ5zuSCW.jpg', 'jpg', 'gtI/gtIAZvqLaySeTy2m87fVtHDIEl6jKhqnLZ5zuSCW.jpg', NULL, NULL, 'questions', '2025-11-02 16:57:59', '2025-11-02 16:57:59'),
(14, 'E9gXctJNcxMH1LtEtYZS4h7IFWVOaN8TnrrznzzS.jpg', 'jpg', 'E9g/E9gXctJNcxMH1LtEtYZS4h7IFWVOaN8TnrrznzzS.jpg', NULL, NULL, 'users', '2025-11-08 06:52:51', '2025-11-08 06:52:51'),
(15, 'jBJIzXsZgA7Z8ZrbYenhO7NqYlhFMJVpjPqH6kCi.jpg', 'jpg', 'jBJ/jBJIzXsZgA7Z8ZrbYenhO7NqYlhFMJVpjPqH6kCi.jpg', NULL, NULL, 'categories', '2025-11-08 15:36:26', '2025-11-08 15:36:26'),
(16, '4cDc1tCeYFN4lBhWjk4kl5NDNoQfR9ffwWchNMKX.jpg', 'jpg', '4cD/4cDc1tCeYFN4lBhWjk4kl5NDNoQfR9ffwWchNMKX.jpg', NULL, NULL, 'questions', '2025-11-08 16:44:19', '2025-11-08 16:44:19'),
(17, '6i9iZfCfQLa3D3VhpL847eZyaI7GdT30dJKoKJeA.jpg', 'jpg', '6i9/6i9iZfCfQLa3D3VhpL847eZyaI7GdT30dJKoKJeA.jpg', NULL, NULL, 'questions', '2025-11-08 16:44:56', '2025-11-08 16:44:56'),
(18, 'qnZ3kZeYv8CVKbXRlsh1cEwQ2vGaf9OiOCPbDchm.gif', 'gif', 'qnZ/qnZ3kZeYv8CVKbXRlsh1cEwQ2vGaf9OiOCPbDchm.gif', NULL, NULL, 'questions', '2025-12-24 08:24:00', '2025-12-24 08:24:00'),
(19, 'c211fe15-782b-3fa9-918e-40a1d7c368b5.jpg', 'jpg', 'c21/c211fe15-782b-3fa9-918e-40a1d7c368b5.jpg', NULL, NULL, 'categories', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(20, '04c5975b-ceaa-3bc2-bcd3-5fe16c2003c7.png', 'png', '04c/04c5975b-ceaa-3bc2-bcd3-5fe16c2003c7.png', NULL, NULL, 'questions', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(21, '11160cc3-67b8-3769-b438-666aae628f81.jpeg', 'jpeg', '111/11160cc3-67b8-3769-b438-666aae628f81.jpeg', NULL, NULL, 'categories', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(22, '0cdec846-9d24-31db-a0cd-b56026836f59.jpeg', 'jpeg', '0cd/0cdec846-9d24-31db-a0cd-b56026836f59.jpeg', NULL, NULL, 'questions', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(23, '144a9e28-cc75-3987-99bf-f0a2209eefad.jpeg', 'jpeg', '144/144a9e28-cc75-3987-99bf-f0a2209eefad.jpeg', NULL, NULL, 'categories', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(24, 'bb1d0f85-aac2-3f99-8b22-195c12e0f1f1.jpeg', 'jpeg', 'bb1/bb1d0f85-aac2-3f99-8b22-195c12e0f1f1.jpeg', NULL, NULL, 'questions', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(25, '8f77d3a5-14cd-3699-8638-5e605974b80a.jpeg', 'jpeg', '8f7/8f77d3a5-14cd-3699-8638-5e605974b80a.jpeg', NULL, NULL, 'categories', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(26, '9956155b-a1f6-3671-b9f9-4bfb3555ec19.jpeg', 'jpeg', '995/9956155b-a1f6-3671-b9f9-4bfb3555ec19.jpeg', NULL, NULL, 'questions', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(27, '53a9758e-e972-33db-b970-0ec554119d31.jpeg', 'jpeg', '53a/53a9758e-e972-33db-b970-0ec554119d31.jpeg', NULL, NULL, 'categories', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(28, '3fcf6fa9-c5c3-3a73-8b07-716ac7535158.jpg', 'jpg', '3fc/3fcf6fa9-c5c3-3a73-8b07-716ac7535158.jpg', NULL, NULL, 'questions', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(29, '21013e44-7193-3f99-9f64-7ee5b3bd02bb.png', 'png', '210/21013e44-7193-3f99-9f64-7ee5b3bd02bb.png', NULL, NULL, 'categories', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(30, 'c9b2dc24-b3b0-3af4-be54-f745df693d8d.jpg', 'jpg', 'c9b/c9b2dc24-b3b0-3af4-be54-f745df693d8d.jpg', NULL, NULL, 'questions', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(31, '1c8ea806-4c45-394f-954b-f71a6377025c.png', 'png', '1c8/1c8ea806-4c45-394f-954b-f71a6377025c.png', NULL, NULL, 'categories', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(32, '9dd47635-258b-344e-9ff1-be0ac7b5bab8.jpg', 'jpg', '9dd/9dd47635-258b-344e-9ff1-be0ac7b5bab8.jpg', NULL, NULL, 'questions', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(33, 'fd5770e7-baf9-32dd-b0f1-78dde4ce08fe.jpeg', 'jpeg', 'fd5/fd5770e7-baf9-32dd-b0f1-78dde4ce08fe.jpeg', NULL, NULL, 'categories', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(34, '9d78d6d3-bbe9-3f71-b232-72bf3095e908.jpg', 'jpg', '9d7/9d78d6d3-bbe9-3f71-b232-72bf3095e908.jpg', NULL, NULL, 'questions', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(35, 'e413c493-3f29-30a4-9e97-7f0b60c698da.png', 'png', 'e41/e413c493-3f29-30a4-9e97-7f0b60c698da.png', NULL, NULL, 'categories', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(36, '63acf171-fe01-33b7-94a0-0a2d9a3f4ad1.png', 'png', '63a/63acf171-fe01-33b7-94a0-0a2d9a3f4ad1.png', NULL, NULL, 'questions', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(37, '9280c60e-6174-3b95-840a-4347fb0d7150.jpg', 'jpg', '928/9280c60e-6174-3b95-840a-4347fb0d7150.jpg', NULL, NULL, 'categories', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(38, '48cdc4ba-c8ec-3f04-983f-e6bf0121d05b.jpeg', 'jpeg', '48c/48cdc4ba-c8ec-3f04-983f-e6bf0121d05b.jpeg', NULL, NULL, 'questions', '2026-01-03 05:58:41', '2026-01-03 05:58:41'),
(39, '1ec5be77-0759-337f-9504-58f6dad2ca60.jpg', 'jpg', '1ec/1ec5be77-0759-337f-9504-58f6dad2ca60.jpg', NULL, NULL, 'categories', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(40, '6255d680-2b8c-3ae0-9ee4-3ee7de854408.png', 'png', '625/6255d680-2b8c-3ae0-9ee4-3ee7de854408.png', NULL, NULL, 'questions', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(41, 'd259d76e-c053-3795-84d9-30c47d3d2442.jpeg', 'jpeg', 'd25/d259d76e-c053-3795-84d9-30c47d3d2442.jpeg', NULL, NULL, 'categories', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(42, '4f159915-6cde-3464-bae1-75d0b376b7ce.png', 'png', '4f1/4f159915-6cde-3464-bae1-75d0b376b7ce.png', NULL, NULL, 'questions', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(43, '6031f40e-3ec7-325c-b2b3-7be76f03ebcd.jpeg', 'jpeg', '603/6031f40e-3ec7-325c-b2b3-7be76f03ebcd.jpeg', NULL, NULL, 'categories', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(44, '1141e6a8-6bf2-3a60-a2bd-a09b4c55055f.png', 'png', '114/1141e6a8-6bf2-3a60-a2bd-a09b4c55055f.png', NULL, NULL, 'questions', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(45, '0e89d315-e1b8-3ef4-8ff5-4390622fee80.png', 'png', '0e8/0e89d315-e1b8-3ef4-8ff5-4390622fee80.png', NULL, NULL, 'categories', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(46, '12bb67ab-e347-3549-8c5b-0cec7facc8a9.jpeg', 'jpeg', '12b/12bb67ab-e347-3549-8c5b-0cec7facc8a9.jpeg', NULL, NULL, 'questions', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(47, '93f2ff29-c5e7-3d78-8e7b-daa51eeacc89.png', 'png', '93f/93f2ff29-c5e7-3d78-8e7b-daa51eeacc89.png', NULL, NULL, 'categories', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(48, '96244591-6ff0-3d42-9697-8355e261bf31.jpeg', 'jpeg', '962/96244591-6ff0-3d42-9697-8355e261bf31.jpeg', NULL, NULL, 'questions', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(49, '36e90cd0-1956-334e-8f2b-ae5d6ef0aa59.png', 'png', '36e/36e90cd0-1956-334e-8f2b-ae5d6ef0aa59.png', NULL, NULL, 'categories', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(50, 'f994ee08-74bb-3d42-a2eb-5b12c62b7fee.png', 'png', 'f99/f994ee08-74bb-3d42-a2eb-5b12c62b7fee.png', NULL, NULL, 'questions', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(51, 'c1d14810-232a-3db8-a745-90a5d0a99acb.jpeg', 'jpeg', 'c1d/c1d14810-232a-3db8-a745-90a5d0a99acb.jpeg', NULL, NULL, 'categories', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(52, 'bc9beb18-a4e8-3cfa-8952-da7081cf45df.jpg', 'jpg', 'bc9/bc9beb18-a4e8-3cfa-8952-da7081cf45df.jpg', NULL, NULL, 'questions', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(53, 'b50d722f-7bca-3c7a-b2e8-b8371df0a70f.jpeg', 'jpeg', 'b50/b50d722f-7bca-3c7a-b2e8-b8371df0a70f.jpeg', NULL, NULL, 'categories', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(54, 'b5093209-c8d2-3c53-8b10-1bdd4c0fdbe1.png', 'png', 'b50/b5093209-c8d2-3c53-8b10-1bdd4c0fdbe1.png', NULL, NULL, 'questions', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(55, '34ef2ff4-b15f-3b41-9a54-17f0b294edf7.png', 'png', '34e/34ef2ff4-b15f-3b41-9a54-17f0b294edf7.png', NULL, NULL, 'categories', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(56, 'bcc1c4e4-7dc8-31ce-abf8-160a192a7d33.jpeg', 'jpeg', 'bcc/bcc1c4e4-7dc8-31ce-abf8-160a192a7d33.jpeg', NULL, NULL, 'questions', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(57, '58c041c4-7bd7-3961-8729-13254bceb89b.png', 'png', '58c/58c041c4-7bd7-3961-8729-13254bceb89b.png', NULL, NULL, 'categories', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(58, '8aa12cfe-d97c-3d92-9c92-1c7c1a4edb16.jpg', 'jpg', '8aa/8aa12cfe-d97c-3d92-9c92-1c7c1a4edb16.jpg', NULL, NULL, 'questions', '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(59, 'xOU9WojIs0YTwx2xziDy2VYQKdqVRoYZ0iPpVand.png', 'png', 'xOU/xOU9WojIs0YTwx2xziDy2VYQKdqVRoYZ0iPpVand.png', NULL, NULL, 'categories', '2026-01-03 15:32:25', '2026-01-03 15:32:25'),
(60, 'jB2AuEnP7QD34wY6NQ1nFEQ9nvkZwVcfD9Bs7yxa.png', 'png', 'jB2/jB2AuEnP7QD34wY6NQ1nFEQ9nvkZwVcfD9Bs7yxa.png', NULL, NULL, 'questions', '2026-01-06 11:59:13', '2026-01-06 11:59:13'),
(61, 'IDDGl6VF6cOJ3Oj0YnNuk8WcYcWaYJQlEpxp7K34.png', 'png', 'IDD/IDDGl6VF6cOJ3Oj0YnNuk8WcYcWaYJQlEpxp7K34.png', NULL, NULL, 'questions', '2026-01-20 08:34:50', '2026-01-20 08:34:50'),
(62, '0BS7JOSqcixbD1uwFW2UGAVpkVknQEnX8XwtSKCL.jpg', 'jpg', '0BS/0BS7JOSqcixbD1uwFW2UGAVpkVknQEnX8XwtSKCL.jpg', NULL, NULL, 'questions', '2026-01-20 08:39:01', '2026-01-20 08:39:01'),
(63, 'hhrT8ILkv06TtD1Lp0XlZMn3uI4UCRtsNUtYWIU0.jpg', 'jpg', 'hhr/hhrT8ILkv06TtD1Lp0XlZMn3uI4UCRtsNUtYWIU0.jpg', NULL, NULL, 'questions', '2026-01-20 08:40:32', '2026-01-20 08:40:32'),
(64, 'HMhKwjkfdCesw0v69VnP8SlPoopR7NvjzuQu7Tte.jpg', 'jpg', 'HMh/HMhKwjkfdCesw0v69VnP8SlPoopR7NvjzuQu7Tte.jpg', NULL, NULL, 'questions', '2026-01-20 08:45:21', '2026-01-20 08:45:21'),
(65, 'VrgErpJ9dEFy0hlwxsdihniHNQf0XiLh01fcmHnr.jpg', 'jpg', 'Vrg/VrgErpJ9dEFy0hlwxsdihniHNQf0XiLh01fcmHnr.jpg', NULL, NULL, 'users', '2026-01-20 08:45:55', '2026-01-20 08:45:55'),
(66, 'Eiz2NWxEyjT0MDFrjrA1HQiu0vnbpC0lsL1NWnEu.jpg', 'jpg', 'Eiz/Eiz2NWxEyjT0MDFrjrA1HQiu0vnbpC0lsL1NWnEu.jpg', NULL, NULL, 'users', '2026-01-20 08:55:39', '2026-01-20 08:55:39'),
(67, '34vtJ9Bhhc6m5hJOZIuf78mwAZ7hGZj2vKiBQTbZ.jpg', 'jpg', '34v/34vtJ9Bhhc6m5hJOZIuf78mwAZ7hGZj2vKiBQTbZ.jpg', NULL, NULL, 'users', '2026-01-20 09:05:34', '2026-01-20 09:05:34');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(14, '0001_01_01_000001_create_cache_table', 2),
(15, '2024_04_14_153225_create_comments_table', 2),
(16, '2024_04_14_155757_create_comment_user_statuses_table', 2),
(18, '2024_04_15_074360_create_files_table', 2),
(22, '2024_04_15_081643_create_question_user_statuses_table', 2),
(28, '2024_04_14_155757_create_comment_user_votes_table', 3),
(29, '2024_04_15_074400_create_categories_table', 3),
(30, '2024_04_15_075201_create_questions_table', 3),
(31, '2024_04_15_080658_create_question_statistics_table', 3),
(32, '2024_04_15_081643_create_question_user_votes_table', 3),
(33, '2024_04_15_101921_create_question_comments_table', 3),
(34, '2024_06_20_115018_create_user_comments_table', 3),
(35, '2024_07_08_081554_create_feedback_table', 3),
(36, '2025_11_02_100258_create_settings_table', 4),
(37, '2024_04_14_165704_create_comments_replies_table', 5),
(38, '2024_04_15_081643_create_question_votes_table', 6),
(40, '2026_01_07_135059_create_tags_table', 7),
(41, '2026_01_08_121505_create_question_tags_table', 8),
(42, '2026_01_21_104615_create_user_tags_table', 9);

-- --------------------------------------------------------

--
-- Структура таблицы `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `questions`
--

CREATE TABLE `questions` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `category_id` bigint UNSIGNED DEFAULT NULL,
  `file_id` bigint UNSIGNED DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `right_comment_id` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `questions`
--

INSERT INTO `questions` (`id`, `user_id`, `category_id`, `file_id`, `title`, `code`, `active`, `right_comment_id`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 18, 'Тестовый вопрос', 'testovyi-vopros', 1, NULL, '2025-12-24 08:24:00', '2025-12-24 08:24:00'),
(2, 3, 11, 40, 'Assumenda repellendus expedita doloremque odit qui laudantium eum.', 'assumenda-repellendus-expedita-doloremque-odit-qui-laudantium-eum', 0, NULL, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(3, 2, 12, 42, 'Et recusandae enim nesciunt dolorem doloremque qui.', 'et-recusandae-enim-nesciunt-dolorem-doloremque-qui', 0, NULL, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(4, 2, 3, 44, 'Quia quis ut nihil ut.', 'quia-quis-ut-nihil-ut', 1, NULL, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(5, 1, 1, 46, 'Et ut enim eum incidunt.', 'et-ut-enim-eum-incidunt', 1, 7, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(6, 3, 15, 48, 'Sit qui architecto maxime est vel voluptatem.', 'sit-qui-architecto-maxime-est-vel-voluptatem', 0, NULL, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(7, 1, 16, 50, 'Quibusdam commodi impedit eum eos.', 'quibusdam-commodi-impedit-eum-eos', 1, NULL, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(8, 3, 17, 52, 'Inventore nulla ea nihil sed.', 'inventore-nulla-ea-nihil-sed', 1, NULL, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(9, 1, 18, 54, 'Reiciendis quo velit officiis velit et debitis sit.', 'reiciendis-quo-velit-officiis-velit-et-debitis-sit', 0, NULL, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(10, 3, 19, 56, 'Magni voluptas deleniti nam consectetur.', 'magni-voluptas-deleniti-nam-consectetur', 1, NULL, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(11, 1, 20, 58, 'Sapiente aut maxime autem.', 'sapiente-aut-maxime-autem', 0, NULL, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(12, 3, 8, 60, 'ениум тест вопроса', 'enium-test-voprosa', 0, NULL, '2026-01-06 11:59:13', '2026-01-06 11:59:13'),
(13, 2, 11, NULL, 'когда в наруто сломали горы-лица', 'kogda-v-naruto-slomali-gory-lica', 1, NULL, '2026-01-08 07:47:58', '2026-01-08 07:47:58'),
(14, 2, 5, NULL, 'ахуительный котеночек есть такое аниме?', 'axuitelnyi-kotenocek-est-takoe-anime', 1, NULL, '2026-01-08 07:49:47', '2026-01-08 07:49:47'),
(15, 2, NULL, NULL, 'ахуительный котенок есть такое аниме?', 'axuitelnyi-kotenok-est-takoe-anime', 1, NULL, '2026-01-08 07:51:23', '2026-01-08 07:51:23'),
(16, 2, NULL, NULL, 'ахуитительный котеночек есть такое аниме?', 'axuititelnyi-kotenocek-est-takoe-anime', 1, NULL, '2026-01-08 07:52:21', '2026-01-08 07:52:21'),
(17, 2, NULL, NULL, 'Тест тегов', 'test-tegov', 1, NULL, '2026-01-08 07:53:18', '2026-01-08 07:53:18'),
(18, 2, NULL, NULL, 'тест тегов повторный', 'test-tegov-povtornyi', 1, NULL, '2026-01-08 07:53:55', '2026-01-08 07:53:55'),
(19, 3, 8, 61, 'test pic', 'test-pic', 0, NULL, '2026-01-20 08:34:50', '2026-01-20 08:34:50'),
(20, 2, 5, 63, 'test pic 2', 'test-pic-2', 1, NULL, '2026-01-20 08:40:32', '2026-01-20 08:40:32'),
(21, 2, 16, 64, 'testtt', 'testtt', 1, NULL, '2026-01-20 08:45:21', '2026-01-20 08:45:21');

-- --------------------------------------------------------

--
-- Структура таблицы `question_comments`
--

CREATE TABLE `question_comments` (
  `id` bigint UNSIGNED NOT NULL,
  `question_id` bigint UNSIGNED NOT NULL,
  `comment_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `question_comments`
--

INSERT INTO `question_comments` (`id`, `question_id`, `comment_id`, `created_at`, `updated_at`) VALUES
(1, 9, 3, '2026-01-03 06:15:29', '2026-01-03 06:15:29'),
(2, 8, 4, '2026-01-03 06:15:29', '2026-01-03 06:15:29'),
(3, 7, 5, '2026-01-03 06:15:29', '2026-01-03 06:15:29'),
(4, 9, 6, '2026-01-03 06:15:29', '2026-01-03 06:15:29'),
(5, 5, 7, '2026-01-03 06:15:29', '2026-01-03 06:15:29'),
(6, 9, 8, '2026-01-03 06:15:29', '2026-01-03 06:15:29'),
(7, 9, 9, '2026-01-03 06:15:29', '2026-01-03 06:15:29'),
(8, 6, 10, '2026-01-03 06:15:29', '2026-01-03 06:15:29'),
(9, 5, 11, '2026-01-03 06:15:29', '2026-01-03 06:15:29'),
(10, 9, 12, '2026-01-03 06:15:29', '2026-01-03 06:15:29'),
(11, 11, 13, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(12, 8, 14, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(13, 6, 15, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(14, 8, 16, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(15, 1, 17, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(16, 8, 18, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(17, 5, 19, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(18, 2, 20, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(19, 2, 21, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(20, 2, 22, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(21, 4, 23, '2026-01-04 04:52:38', '2026-01-04 04:52:38');

-- --------------------------------------------------------

--
-- Структура таблицы `question_statistics`
--

CREATE TABLE `question_statistics` (
  `id` bigint UNSIGNED NOT NULL,
  `question_id` bigint UNSIGNED NOT NULL,
  `views` bigint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `question_statistics`
--

INSERT INTO `question_statistics` (`id`, `question_id`, `views`, `created_at`, `updated_at`) VALUES
(1, 1, 5, '2025-12-24 08:24:00', '2026-01-09 10:13:10'),
(2, 2, 0, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(3, 3, 0, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(4, 4, 9, '2026-01-03 06:00:09', '2026-01-11 07:19:33'),
(5, 5, 4, '2026-01-03 06:00:09', '2026-01-07 06:31:27'),
(6, 6, 0, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(7, 7, 1, '2026-01-03 06:00:09', '2026-01-03 08:10:48'),
(8, 8, 2, '2026-01-03 06:00:09', '2026-01-06 08:25:16'),
(9, 9, 0, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(10, 10, 1, '2026-01-03 06:00:09', '2026-01-03 09:12:36'),
(11, 11, 0, '2026-01-03 06:00:09', '2026-01-03 06:00:09'),
(12, 12, 0, '2026-01-06 11:59:13', '2026-01-06 11:59:13'),
(13, 13, 0, '2026-01-08 07:47:58', '2026-01-08 07:47:58'),
(14, 14, 0, '2026-01-08 07:49:47', '2026-01-08 07:49:47'),
(15, 15, 0, '2026-01-08 07:51:23', '2026-01-08 07:51:23'),
(16, 16, 0, '2026-01-08 07:52:21', '2026-01-08 07:52:21'),
(17, 17, 0, '2026-01-08 07:53:18', '2026-01-08 07:53:18'),
(18, 18, 0, '2026-01-08 07:53:55', '2026-01-08 07:53:55'),
(19, 19, 0, '2026-01-20 08:34:50', '2026-01-20 08:34:50'),
(20, 20, 0, '2026-01-20 08:40:32', '2026-01-20 08:40:32'),
(21, 21, 0, '2026-01-20 08:45:21', '2026-01-20 08:45:21');

-- --------------------------------------------------------

--
-- Структура таблицы `question_tags`
--

CREATE TABLE `question_tags` (
  `id` bigint UNSIGNED NOT NULL,
  `question_id` bigint UNSIGNED NOT NULL,
  `tag_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `question_tags`
--

INSERT INTO `question_tags` (`id`, `question_id`, `tag_id`, `created_at`, `updated_at`) VALUES
(1, 17, 1, '2026-01-08 07:53:18', '2026-01-08 07:53:18'),
(2, 17, 3, '2026-01-08 07:53:18', '2026-01-08 07:53:18'),
(3, 17, 5, '2026-01-08 07:53:18', '2026-01-08 07:53:18'),
(4, 18, 3, '2026-01-08 07:53:55', '2026-01-08 07:53:55'),
(5, 18, 4, '2026-01-08 07:53:56', '2026-01-08 07:53:56'),
(6, 18, 5, '2026-01-08 07:53:56', '2026-01-08 07:53:56'),
(7, 21, 4, '2026-01-20 08:45:21', '2026-01-20 08:45:21');

-- --------------------------------------------------------

--
-- Структура таблицы `question_user_votes`
--

CREATE TABLE `question_user_votes` (
  `id` bigint UNSIGNED NOT NULL,
  `question_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `vote` tinyint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `question_user_votes`
--

INSERT INTO `question_user_votes` (`id`, `question_id`, `user_id`, `vote`, `created_at`, `updated_at`) VALUES
(1, 4, 3, -1, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(2, 3, 2, -1, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(3, 11, 3, -1, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(4, 11, 3, -1, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(5, 4, 2, 1, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(6, 7, 2, -1, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(7, 5, 1, -1, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(8, 4, 3, 1, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(9, 11, 1, 1, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(10, 3, 3, 1, '2026-01-03 06:17:24', '2026-01-03 06:17:24'),
(11, 5, 3, 1, '2026-01-06 11:17:06', '2026-01-06 11:17:06');

-- --------------------------------------------------------

--
-- Структура таблицы `question_votes`
--

CREATE TABLE `question_votes` (
  `id` bigint UNSIGNED NOT NULL,
  `question_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `vote` tinyint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

CREATE TABLE `settings` (
  `id` bigint UNSIGNED NOT NULL,
  `area` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'main',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `area`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'main', 'captcha_set_on', 'false', '2026-01-08 07:27:52', '2026-01-08 07:27:52'),
(2, 'integration', 'gemini_validate_user_photos', 'true', '2026-01-20 08:38:40', '2026-01-20 08:38:40');

-- --------------------------------------------------------

--
-- Структура таблицы `tags`
--

CREATE TABLE `tags` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort` smallint NOT NULL DEFAULT '300'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `tags`
--

INSERT INTO `tags` (`id`, `name`, `sort`) VALUES
(1, 'Аниме', 300),
(2, 'Горы', 300),
(3, 'Кошки', 300),
(4, 'Природа', 300),
(5, 'Компьютеры', 300);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `photo_id` bigint UNSIGNED DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `role`, `active`, `photo_id`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Test User', 'user', 0, NULL, 'test@example.com', '2025-10-26 14:38:22', '$2y$12$I501fpzvXnYqF4tNawwHeOrB22no0JyuyzkFFURXLr0d3rFThvW/S', 'FccnBfupeO', '2025-10-26 14:38:22', '2025-10-26 14:38:22'),
(2, 'igor221', 'admin', 0, 14, 'gustavforeli@gmail.com', NULL, '$2y$12$CivqebVgE6C/yHNc0HRjq.I.G/07MP8tSMldzU2Mtz6GA5QDDngXC', NULL, '2025-10-26 14:48:38', '2025-11-08 10:22:51'),
(3, 'Игорь Шоколад', 'user', 0, NULL, 'KorovaDlyaOvec@yandex.ru', NULL, '$2y$12$5WuliccO0K.HjLmi.FN5muevZyPDpqfrICw1XSOuTvund4YZo.A06', NULL, '2025-11-03 15:11:32', '2025-11-03 15:11:32'),
(4, 'testmail', 'user', 0, NULL, 'testmail@mail.ru', NULL, '$2y$12$ruA1UrxgcLc0jz1dNSdAP.xjoRciTOwFQd9ppf9p1zsG8dMbVuacq', NULL, '2026-01-04 04:52:21', '2026-01-04 04:52:21');

-- --------------------------------------------------------

--
-- Структура таблицы `user_comments`
--

CREATE TABLE `user_comments` (
  `id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `comment_id` bigint UNSIGNED NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `user_comments`
--

INSERT INTO `user_comments` (`id`, `created_at`, `updated_at`, `user_id`, `comment_id`, `deleted_at`) VALUES
(1, '2026-01-03 06:15:29', '2026-01-03 06:15:29', 1, 3, NULL),
(2, '2026-01-03 06:15:29', '2026-01-03 06:15:29', 2, 4, NULL),
(3, '2026-01-03 06:15:29', '2026-01-03 06:15:29', 1, 5, NULL),
(4, '2026-01-03 06:15:29', '2026-01-03 06:15:29', 1, 6, NULL),
(5, '2026-01-03 06:15:29', '2026-01-03 06:15:29', 2, 7, NULL),
(6, '2026-01-03 06:15:29', '2026-01-03 06:15:29', 3, 8, NULL),
(7, '2026-01-03 06:15:29', '2026-01-03 06:15:29', 1, 9, NULL),
(8, '2026-01-03 06:15:29', '2026-01-03 06:15:29', 2, 10, NULL),
(9, '2026-01-03 06:15:29', '2026-01-03 06:15:29', 1, 11, NULL),
(10, '2026-01-03 06:15:29', '2026-01-03 06:15:29', 3, 12, NULL),
(11, '2026-01-03 06:17:24', '2026-01-03 06:17:24', 1, 13, NULL),
(12, '2026-01-03 06:17:24', '2026-01-03 06:17:24', 1, 14, NULL),
(13, '2026-01-03 06:17:24', '2026-01-03 06:17:24', 2, 15, NULL),
(14, '2026-01-03 06:17:24', '2026-01-03 06:17:24', 3, 16, NULL),
(15, '2026-01-03 06:17:24', '2026-01-03 06:17:24', 2, 17, NULL),
(16, '2026-01-03 06:17:24', '2026-01-03 06:17:24', 3, 18, NULL),
(17, '2026-01-03 06:17:24', '2026-01-03 06:17:24', 1, 19, NULL),
(18, '2026-01-03 06:17:24', '2026-01-03 06:17:24', 1, 20, NULL),
(19, '2026-01-03 06:17:24', '2026-01-03 06:17:24', 2, 21, NULL),
(20, '2026-01-03 06:17:24', '2026-01-03 06:17:24', 3, 22, NULL),
(21, '2026-01-04 04:52:38', '2026-01-04 04:52:38', 4, 23, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `user_tags`
--

CREATE TABLE `user_tags` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `tag_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_code_unique` (`code`),
  ADD KEY `categories_file_idx` (`file_id`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_user_idx` (`user_id`);

--
-- Индексы таблицы `comments_replies`
--
ALTER TABLE `comments_replies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_replies_comment_main_idx` (`comment_main_id`),
  ADD KEY `comments_replies_comment_reply_idx` (`comment_reply_id`);

--
-- Индексы таблицы `comment_user_votes`
--
ALTER TABLE `comment_user_votes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comment_user_votes_comment_idx` (`comment_id`),
  ADD KEY `comment_user_votes_user_idx` (`user_id`);

--
-- Индексы таблицы `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `files_path_unique` (`path`),
  ADD UNIQUE KEY `files_path_thumbnail_unique` (`path_thumbnail`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Индексы таблицы `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `questions_code_unique` (`code`),
  ADD KEY `questions_user_idx` (`user_id`),
  ADD KEY `questions_category_idx` (`category_id`),
  ADD KEY `questions_file_idx` (`file_id`),
  ADD KEY `questions_title_idx` (`title`),
  ADD KEY `questions_right_comment_idx` (`right_comment_id`);

--
-- Индексы таблицы `question_comments`
--
ALTER TABLE `question_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_comments_question_idx` (`question_id`),
  ADD KEY `question_comments_comment_idx` (`comment_id`);

--
-- Индексы таблицы `question_statistics`
--
ALTER TABLE `question_statistics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_statistics_question_idx` (`question_id`);

--
-- Индексы таблицы `question_tags`
--
ALTER TABLE `question_tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_tags_question_id_index` (`question_id`),
  ADD KEY `question_tags_tag_id_index` (`tag_id`);

--
-- Индексы таблицы `question_user_votes`
--
ALTER TABLE `question_user_votes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_user_votes_question_idx` (`question_id`),
  ADD KEY `question_user_votes_user_idx` (`user_id`);

--
-- Индексы таблицы `question_votes`
--
ALTER TABLE `question_votes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `question_user_votes_question_idx` (`question_id`);

--
-- Индексы таблицы `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_name_unique` (`name`);

--
-- Индексы таблицы `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_photo_idx` (`photo_id`);

--
-- Индексы таблицы `user_comments`
--
ALTER TABLE `user_comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_comments_user_idx` (`user_id`),
  ADD KEY `user_comments_comment_idx` (`comment_id`);

--
-- Индексы таблицы `user_tags`
--
ALTER TABLE `user_tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_tags_user_id_index` (`user_id`),
  ADD KEY `user_tags_tag_id_index` (`tag_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT для таблицы `comments_replies`
--
ALTER TABLE `comments_replies`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `comment_user_votes`
--
ALTER TABLE `comment_user_votes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT для таблицы `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `question_comments`
--
ALTER TABLE `question_comments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `question_statistics`
--
ALTER TABLE `question_statistics`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `question_tags`
--
ALTER TABLE `question_tags`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `question_user_votes`
--
ALTER TABLE `question_user_votes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `question_votes`
--
ALTER TABLE `question_votes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `user_comments`
--
ALTER TABLE `user_comments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `user_tags`
--
ALTER TABLE `user_tags`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_file_fk` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `comments_replies`
--
ALTER TABLE `comments_replies`
  ADD CONSTRAINT `comments_replies_comments_fk_main` FOREIGN KEY (`comment_main_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_replies_comments_fk_reply` FOREIGN KEY (`comment_reply_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `comment_user_votes`
--
ALTER TABLE `comment_user_votes`
  ADD CONSTRAINT `comment_user_votes_comments_fk` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comment_user_votes_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_category_fk` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `questions_comment_fk` FOREIGN KEY (`right_comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `questions_file_fk` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `questions_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `question_comments`
--
ALTER TABLE `question_comments`
  ADD CONSTRAINT `question_comments_comment_fk` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `question_comments_question_fk` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `question_statistics`
--
ALTER TABLE `question_statistics`
  ADD CONSTRAINT `question_statistics_question_fk` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `question_tags`
--
ALTER TABLE `question_tags`
  ADD CONSTRAINT `question_tags_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `question_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `question_user_votes`
--
ALTER TABLE `question_user_votes`
  ADD CONSTRAINT `question_user_votes_question_fk` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `question_user_votes_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_files_fk` FOREIGN KEY (`photo_id`) REFERENCES `files` (`id`);

--
-- Ограничения внешнего ключа таблицы `user_comments`
--
ALTER TABLE `user_comments`
  ADD CONSTRAINT `user_comments_comment_fk` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_comments_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `user_tags`
--
ALTER TABLE `user_tags`
  ADD CONSTRAINT `user_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
