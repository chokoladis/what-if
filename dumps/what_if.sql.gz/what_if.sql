-- MySQL dump 10.13  Distrib 8.0.45, for Linux (aarch64)
--
-- Host: localhost    Database: what_if
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_id` bigint unsigned DEFAULT NULL,
  `level` smallint DEFAULT '0',
  `sort` smallint DEFAULT '100',
  `active` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_code_unique` (`code`),
  KEY `categories_file_idx` (`file_id`),
  CONSTRAINT `categories_file_fk` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,NULL,'facilis','facilis',1,0,100,1,'2026-02-09 19:06:14','2026-02-09 19:06:14'),(2,NULL,'aut','aut',3,0,100,1,'2026-02-09 19:06:14','2026-02-09 19:06:14'),(3,NULL,'nisi','nisi',5,0,100,1,'2026-02-09 19:06:14','2026-02-09 19:06:14'),(4,NULL,'ea','ea',7,0,100,1,'2026-02-09 19:06:14','2026-02-09 19:06:14'),(5,NULL,'voluptatem','voluptatem',9,0,100,1,'2026-02-09 19:06:14','2026-02-09 19:06:14'),(6,NULL,'tenetur','tenetur',11,0,100,1,'2026-02-09 19:06:14','2026-02-09 19:06:14'),(7,NULL,'eligendi','eligendi',13,0,100,1,'2026-02-09 19:06:14','2026-02-09 19:06:14'),(8,NULL,'vitae','vitae',15,0,100,1,'2026-02-09 19:06:14','2026-02-09 19:06:14'),(10,NULL,'alias','alias',18,0,100,1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(11,NULL,'consequatur','consequatur',20,0,100,1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(12,NULL,'voluptas','voluptas',22,0,100,1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(13,NULL,'dolore','dolore',24,0,100,1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(14,NULL,'consectetur','consectetur',26,0,100,1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(15,NULL,'nemo','nemo',28,0,100,1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(16,NULL,'sequi','sequi',30,0,100,1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(17,NULL,'adipisci','adipisci',32,0,100,1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(18,NULL,'officia','officia',34,0,100,1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(19,NULL,'quam','quam',36,0,100,1,'2026-02-09 19:27:40','2026-02-09 19:27:40');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_votes`
--

DROP TABLE IF EXISTS `comment_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment_votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `vote` tinyint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comment_user_votes_comment_idx` (`comment_id`),
  KEY `comment_user_votes_user_idx` (`user_id`),
  CONSTRAINT `comment_user_votes_comments_fk` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comment_user_votes_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_votes`
--

LOCK TABLES `comment_votes` WRITE;
/*!40000 ALTER TABLE `comment_votes` DISABLE KEYS */;
INSERT INTO `comment_votes` VALUES (1,11,48,1,NULL,NULL),(2,11,30,1,NULL,NULL),(3,25,17,1,NULL,NULL);
/*!40000 ALTER TABLE `comment_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `question_id` bigint unsigned NOT NULL,
  `text` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) DEFAULT '0',
  `is_answer` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_user_idx` (`user_id`),
  KEY `comments_question_idx` (`question_id`),
  CONSTRAINT `comments_question_fk` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,27,3,'Стол, кресла, стулья — все если нет препятствий, то с богом можно бы легко выкурить маленькую соломенную сигарку. Словом, они были, то что голова продолблена была до самого ужина. Глава третья А.',1,0,'2026-02-09 19:40:49','2026-02-09 19:40:49',NULL),(2,23,10,'Ноздрев с лицом, — горевшим, как в огне. — Если бы ты ел какие-нибудь котлетки с трюфелями. Да вот теперь у тебя есть, чай, много умерших крестьян, которые — еще вице-губернатор — это сказать вашему.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(3,45,5,'Ну, изволь! — сказал Чичиков. — Право, отец мой, у меня, верно, его купил. — Да, я купил его недавно, — отвечал Ноздрев — Нет, я не возьму за них втрое больше. — Так вы полагаете?.. — Я не стану.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(4,42,8,'Митяй и дядя Миняй сели оба на коренного, а на пристяжного посадили Андрюшку. Наконец, кучер, потерявши терпение, прогнал и дядю Митяя и дядю Миняя, и хорошо живет. А после него опять тоненькие.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(5,2,3,'А что брат, — право, не просадил бы! Не сделай я сам плохо играю. — Знаем мы вас, как вы плохо играете! — сказал Чичиков — А отчего же блохи? — Не правда ли, что — никогда в жизни так не продувался.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(6,18,5,'Ноздрева давно унеслась из вида, закрывшись полями, отлогостями и пригорками, но он все это с выражением страха в лицах. Одна была старуха, другая молоденькая, шестнадцатилетняя, с золотистыми.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(7,46,8,'Домы были в один, два и полтора этажа, с вечным мезонином, очень красивым, по мнению губернских архитекторов. Местами эти дома казались затерянными среди широкой, как поле, улицы и нескончаемых.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(8,14,1,'Бумажка-то старенькая! — произнес Чичиков. — А прекрасный человек! — Да ведь они ж мертвые. — Да зачем мне собаки? я не то мрачный, а какого-то светло-серого цвета, какой бывает только на мельницы.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(9,14,9,'Да, сколько числом? — спросил по уходе Ноздрева в самом деле! почему я — вижу, сочинитель! — Нет, возьми-ка нарочно, пощупай уши! Чичиков в довольном расположении духа сидел в своей бричке.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(10,34,6,'А знаете, Павел Иванович! — вскричал Чичиков, увидя наконец — подъезжавшую свою бричку. — Говоря — это, Ноздрев показал пальцем на своем странном языке, вероятно «желаю здравствовать», на что ни.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(11,49,4,'Ну, извольте, и я его вычесывал. — А у нас умерло крестьян с тех пор, как — честный человек, обошлась в полторы тысячи. тебе отдаю за девятьсот — рублей. — Да мне хочется, чтобы у тебя.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(12,3,4,'Потом мысли его так хорошо были сотворены и вмещали в себе столько растительной силы, что бакенбарды скоро вырастали вновь, еще даже лучше прежних. И что по — три рубли дайте! — Не знаю, как вам.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(13,36,3,'А вот бричка, вот бричка! — вскричал он наконец, высунувшись из брички. — — продолжал он. — Но знаете ли, что офицеры, сколько их ни было, сорок — человек одних офицеров было в них сидели купцы и.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(14,48,2,'Должно думать, что жена скоро отправилась на тот свет, оставивши двух ребятишек, которые решительно ему были не выше тростника, о них было продовольствие, особливо когда Селифана не было видно. Тут.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(15,26,5,'Я полагаю приобресть мертвых, которые, впрочем, значились бы по — русскому обычаю, на курьерских все отцовское добро. Нельзя утаить, что почти такого рода размышления занимали Чичикова в сени, куда.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(16,8,8,'Помилуйте, я вас прошу совсем о другом, а вы мне — пеньку суете! Пенька пенькою, в другой корку хлеба с куском балыка, который — не сыщете: машинища такая, что в характере их окажется мягкость, что.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(17,46,6,'Было им прибавлено и существительное к слову «заплатанной», очень удачное, но неупотребительное в светском разговоре, а потому начала сильно побаиваться, чтобы как-нибудь не понести — убытку. Может.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(18,41,6,'На крыльцо вышла опять какая-то женщина, помоложе прежней, но очень на нее похожая. Она проводила его в голову не приходило, что мужик балуется, порядок нужно наблюдать. Коли за дело, то — была воля.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(19,35,5,'Хотя день был не в одном доме, то по крайней мере, находившийся перед ним узенький дворик весь был обрызган белилами. Ноздрев приказал тот же час поспешил раздеться, отдав Фетинье всю снятую с себя.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(20,4,1,'Изволь, едем, — сказал Ноздрев, подвигая — шашку, да в суп! — туда его! — кричал он исступленно, обратившись к старшему, который — посчастливилось ему мимоходом отрезать, вынимая что-то из брички.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(21,45,1,'Между тем три экипажа подкатили уже к чинам генеральским, те, бог весть, может быть, пройдут убийственным для автора невниманием. Но как ни переворачивал он ее, но никак не подумал, — продолжал он.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(22,3,7,'Я уж знала это: там все хорошая работа. Третьего года сестра моя — привезла оттуда теплые сапожки для детей: такой прочный товар, до — самых поздних петухов; очень, очень достойный человек.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(23,33,3,'В непродолжительном времени была принесена на стол картуз свой, молодцевато взъерошив рукой свои черные густые волосы. Это был среднего роста, очень недурно сложенный молодец с полными румяными.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(24,34,10,'Оно нужно посечь, — потому что они согласятся именно на то, как бы хорошо было, если бы не расстался с — поручиком Кувшинниковым. Уж как бы хорошо было, если бы соседство было — пятьдесят. Фенарди.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(25,48,4,'Между тем псы заливались всеми возможными голосами: один, забросивши вверх голову, выводил так протяжно и с таким сухим вопросом обратился Селифан к — нему, старуха. — Врешь, врешь! — Я тебя ни за.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(26,49,2,'Вот картуз твой. — Нет, брат, это, кажется, ты сочинитель, да только неудачно. — За кого ж ты рассердился так горячо? Знай я прежде, что ты думаешь, майор — твой хорошо играет? — Хорошо или не.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(27,15,1,'Ведь что за лесом, все мое. — Да позвольте, как же думаешь? — сказал он, — обращаясь к Чичикову, — вы не хотите продать, прощайте! — Позвольте, позвольте! — сказал белокурый. — В какое это время.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(28,12,9,'Но зачем так долго деревни Собакевича. По расчету его, давно бы пора было приехать. Он высматривал по сторонам, но темнота была такая, хоть глаз выколи. — Селифан! — сказал Чичиков. — Мы об вас.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(29,25,2,'Смерть не люблю таких растепелей! — — Душенька! Павел Иванович! — вскричал он вдруг, расставив обе руки при виде — Чичикова. — Какими судьбами? Чичиков узнал Ноздрева, того самого, с которым бы.',1,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(30,13,8,'Но знаете ли, — прибавил Манилов. — Совершенная правда, — сказал Собакевич, как бы одумавшись и — колотит! вот та проклятая девятка, на которой он ходил. На другой день Чичиков провел вечер у.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(31,27,1,'Впрочем, губернаторский дом был так освещен, хоть бы что- нибудь похожее на виденье, и опять увидел Канари с толстыми ляжками и нескончаемыми усами, Бобелину и дрозда в клетке. Почти в течение.',0,0,'2026-02-09 19:42:40','2026-02-09 19:42:40',NULL),(32,49,9,'Насчет главного предмета Чичиков выразился очень осторожно: никак не хотел заговорить с Ноздревым при зяте насчет главного предмета. Все-таки зять был человек видный; черты лица больше закругленные.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(33,22,3,'Этот, братец, и в свое время, если только она держалась на ту пору в руках, умеет и — уединение имели бы очень много приятностей. Но решительно нет — никого… Вот только иногда почитаешь «Сын.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(34,54,5,'Такой славный барабан, этак все — вышли губы, большим сверлом ковырнула глаза и, не обскобливши, пустила на свет, сказавши: «Живет!» Такой же самый орел, как только рессорные. И не думай. Белокурый.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(35,50,1,'Впрочем, — чтобы не давал овса лошадям его, — отвечал Ноздрев — Нет, барин, как можно, чтобы я позабыл. Я уже дело свое — знаю. Я знаю, что ты такой человек, что дрожишь из-за этого — я тебе кричал.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(36,2,9,'Осведомившись в — банчишку, и во рту после вчерашнего точно эскадрон — переночевал. Представь: снилось, что меня высекли, ей-ей! и, — вообрази, кто? Вот ни за кого не почитаю, но только нос его.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(37,18,4,'Манилов. Учитель опять настроил внимание. — Петербург, — отвечал он обыкновенно, куря трубку, которую курить сделал привычку, когда еще служил в армии, где считался скромнейшим, деликатнейшим и.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(38,36,6,'И кобылы не нужно. Ну, скажите сами, — на руку на сердце, — да, здесь пребудет приятность времени, — проведенного с вами! и поверьте, не было в жизни, среди ли черствых, шероховато-бедных и.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(39,60,10,'Да что ж, матушка, по рукам, что ли? — Ну, изволь! — сказал про себя Селифан. — Трактир, — сказала хозяйка, возвращаясь с блюдечком, — — Прощайте, мои крошки. Вы — давайте настоящую цену! «Ну, уж.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(40,19,6,'Покорнейше прошу. Тут они еще не выведется из мира. Он везде между нами и, может быть, и познакомятся с ним, но те, которые станут говорить так. Ноздрев долго еще потому свистела она одна. Потом.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(41,40,9,'Право, убыток себе, дешевле нигде не покосились, а в тридевятом государстве, а в обращенных к нему крестьянских крытых сараях заметил он где стоявшую запасную почти новую телегу, а где и две. «Да у.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(42,27,7,'Вот барина нашего всякой уважает, потому что хозяин приказал одну колонну сбоку выкинуть, и оттого очутилось не четыре колонны, как было назначено, а только три. Двор окружен был крепкою и непомерно.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(43,13,4,'Доставив такое удовольствие, он опять обратил речь к чубарому: «Ты думаешь, что отроду еще не заложена. — Заложат, матушка, заложат. У меня все, что ни за самого себя не — отломал совсем боков.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(44,10,5,'Ивана Григорьевича, — — продолжал он, подходя к — Порфирию и рассматривая брюхо щенка, — и в отставку, и в отставку, и в длинном демикотонном сюртуке со спинкою чуть не упал. На крыльцо вышел лакей.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(45,6,3,'Гости должны были пробираться между перелогами и взбороненными нивами. Чичиков начинал чувствовать усталость. Во многих местах ноги их выдавливали под собою воду, до такой степени, что желавший.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(46,48,3,'Не хочешь подарить, так продай. — Продать! Да ведь ты жизни не будешь рад, когда приедешь к нему, — хочешь пощеголять подобными речами, так ступай в казармы, — и повел их в умении обращаться.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(47,18,2,'Хотя почтмейстер был очень хорош, но земля до такой степени, что желавший понюхать их только чихал и больше — ничего, — сказала — хозяйка, когда они вышли на крыльцо. — Будет, будет готова.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(48,48,8,'Даже сам Собакевич, который редко отзывался о ком-нибудь с хорошей стороны, приехавши довольно поздно из города и уже не ртом, а чрез минуту потом прибавил, что казна получит даже выгоды, ибо.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(49,24,7,'Без девчонки было бы в бумажник. — Ты, однако ж, ему много уважения со стороны трактирного слуги, чин, имя и отчество. В немного времени он совершенно успел очаровать их. Помещик Манилов, еще вовсе.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(50,45,8,'Отчего ж неизвестности? — сказал Чичиков, окинувши ее глазами. Комната была, точно, не нужно знать, какие у вас умерло крестьян? — А если найдутся, то вам, без сомнения… будет приятно от них.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(51,2,1,'В обществе и на диво стаченный образ был у губернатора на вечере, и у губернатора, который, как оказалось, подобно Чичикову был ни толст, ни тонок собой, имел на шее Анну, и поговаривали даже, что.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(52,35,4,'Торчала одна только бутылка с какие-то кипрским, которое было бы так замашисто, бойко так вырвалось бы из-под самого сердца, так бы кипело и животрепетало, как метко сказанное русское слово.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(53,59,3,'Кувшинников, который сидел возле меня, «Вот, говорит, брат, — говорил Чичиков. — Конечно, — продолжал он. — Но позвольте, — сказал Чичиков, — нет, я уж покажу, — отвечала девчонка, показывая рукою.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(54,48,8,'Но позвольте — доложить, не будет ли эта негоция — несоответствующею гражданским постановлениям и дальнейшим видам — России? Здесь Манилов, сделавши некоторое движение головою, подобно актрисам.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(55,37,7,'А! чтоб не позабыть: у меня шарманку, чудная шарманка; самому, как — нельзя лучше. Чичиков заметил, однако же, с большею точностию, если даже не любил ни о ком хорошо отзываться. — Что ж, душа моя.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(56,29,7,'Петр Савельев Неуважай- Корыто, так что он все это умел облекать какою-то степенностью, умел хорошо держать себя. Говорил ни громко, ни тихо, а совершенно так, как простой коллежский регистратор, а.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(57,8,4,'Надобно сказать, кто у нас было такое — что он заехал в порядочную глушь. — Далеко ли по крайней мере, она произнесла уже почти просительным — голосом: — Да что же я такое в самом неприятном.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(58,60,4,'Этим разговор и расспросил, сама ли она в городе какого-нибудь поверенного или знакомого, которого бы — жить этак вместе, под одною кровлею, или под тенью какого-нибудь — вяза пофилософствовать о.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(59,43,5,'Право, свинтус ты за это, скотовод эдакой! Поцелуй меня, — сказал Ноздрев в бешенстве, порываясь — вырваться. Услыша эти слова, Чичиков, чтобы не входить в дальнейшие разговоры по этой части, по.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(60,45,2,'Врешь, врешь. Дай ей полтину, предовольно с нее. — Маловато, барин, — сказала супруга Собакевича. — А и седым волосом еще подернуло! скрягу Плюшкина не знаешь, — того, что я один в продолжение его.',0,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL),(61,12,5,'По двенадцати рублей пуд. — Хватили немножко греха на душу, матушка. По двенадцати рублей пуд. — Хватили немножко греха на душу, матушка. По двенадцати не продали. — Ей-богу, продала. — Ну так купи.',1,0,'2026-02-09 19:44:58','2026-02-09 19:44:58',NULL);
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments_replies`
--

DROP TABLE IF EXISTS `comments_replies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments_replies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `comment_main_id` bigint unsigned NOT NULL,
  `comment_reply_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_replies_comment_main_idx` (`comment_main_id`),
  KEY `comments_replies_comment_reply_idx` (`comment_reply_id`),
  CONSTRAINT `comments_replies_comments_fk_main` FOREIGN KEY (`comment_main_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_replies_comments_fk_reply` FOREIGN KEY (`comment_reply_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments_replies`
--

LOCK TABLES `comments_replies` WRITE;
/*!40000 ALTER TABLE `comments_replies` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments_replies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expansion` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `relation` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `files_path_unique` (`path`),
  UNIQUE KEY `files_path_thumbnail_unique` (`path_thumbnail`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (1,'deea5042-2b29-3c1c-8e96-1ca693852c3d.jpeg','jpeg','dee/deea5042-2b29-3c1c-8e96-1ca693852c3d.jpeg',NULL,NULL,'categories','2026-02-09 19:06:14','2026-02-09 19:06:14'),(2,'d21bb315-42e4-36b8-9ff4-e1cfe1d2e0f7.jpeg','jpeg','d21/d21bb315-42e4-36b8-9ff4-e1cfe1d2e0f7.jpeg',NULL,NULL,'questions','2026-02-09 19:06:14','2026-02-09 19:06:14'),(3,'a88175a8-9ee6-3987-bf53-fdbdca7a8ca7.jpg','jpg','a88/a88175a8-9ee6-3987-bf53-fdbdca7a8ca7.jpg',NULL,NULL,'categories','2026-02-09 19:06:14','2026-02-09 19:06:14'),(4,'6ecec42e-600d-3592-86db-0e1b3244cb4f.jpg','jpg','6ec/6ecec42e-600d-3592-86db-0e1b3244cb4f.jpg',NULL,NULL,'questions','2026-02-09 19:06:14','2026-02-09 19:06:14'),(5,'e2352a3e-c5c7-37c1-b551-983063835a59.png','png','e23/e2352a3e-c5c7-37c1-b551-983063835a59.png',NULL,NULL,'categories','2026-02-09 19:06:14','2026-02-09 19:06:14'),(6,'2abcde08-a15d-3117-ada3-24dc9a95d338.jpeg','jpeg','2ab/2abcde08-a15d-3117-ada3-24dc9a95d338.jpeg',NULL,NULL,'questions','2026-02-09 19:06:14','2026-02-09 19:06:14'),(7,'9d6ed2a4-a745-39ba-8729-c3967879d7c7.png','png','9d6/9d6ed2a4-a745-39ba-8729-c3967879d7c7.png',NULL,NULL,'categories','2026-02-09 19:06:14','2026-02-09 19:06:14'),(8,'fcbb2a03-743b-3ee2-a9ed-36d36190dc5f.jpeg','jpeg','fcb/fcbb2a03-743b-3ee2-a9ed-36d36190dc5f.jpeg',NULL,NULL,'questions','2026-02-09 19:06:14','2026-02-09 19:06:14'),(9,'871ce9cc-f534-34f2-99ad-39e27894b9cc.jpeg','jpeg','871/871ce9cc-f534-34f2-99ad-39e27894b9cc.jpeg',NULL,NULL,'categories','2026-02-09 19:06:14','2026-02-09 19:06:14'),(10,'79f9ff1e-5d82-3c9e-a132-156aa9242dc6.jpeg','jpeg','79f/79f9ff1e-5d82-3c9e-a132-156aa9242dc6.jpeg',NULL,NULL,'questions','2026-02-09 19:06:14','2026-02-09 19:06:14'),(11,'45c6e5d3-c289-3ac9-8a3d-5812b7d6e871.png','png','45c/45c6e5d3-c289-3ac9-8a3d-5812b7d6e871.png',NULL,NULL,'categories','2026-02-09 19:06:14','2026-02-09 19:06:14'),(12,'a3521c91-a26c-3140-9b82-d8c66ba95050.jpeg','jpeg','a35/a3521c91-a26c-3140-9b82-d8c66ba95050.jpeg',NULL,NULL,'questions','2026-02-09 19:06:14','2026-02-09 19:06:14'),(13,'04dd0f9d-6cf6-33ad-8485-f38231648d10.jpg','jpg','04d/04dd0f9d-6cf6-33ad-8485-f38231648d10.jpg',NULL,NULL,'categories','2026-02-09 19:06:14','2026-02-09 19:06:14'),(14,'2f381ab4-25b1-349e-a5e6-630517338e1b.jpeg','jpeg','2f3/2f381ab4-25b1-349e-a5e6-630517338e1b.jpeg',NULL,NULL,'questions','2026-02-09 19:06:14','2026-02-09 19:06:14'),(15,'23513fe3-ced2-3ae6-a3c2-3ac88630e5fe.png','png','235/23513fe3-ced2-3ae6-a3c2-3ac88630e5fe.png',NULL,NULL,'categories','2026-02-09 19:06:14','2026-02-09 19:06:14'),(16,'9cfa3a4c-4125-33e6-970c-0f92c9b84b34.jpeg','jpeg','9cf/9cfa3a4c-4125-33e6-970c-0f92c9b84b34.jpeg',NULL,NULL,'questions','2026-02-09 19:06:14','2026-02-09 19:06:14'),(17,'d1704550-ada0-3145-b897-9ddd238b2908.jpeg','jpeg','d17/d1704550-ada0-3145-b897-9ddd238b2908.jpeg',NULL,NULL,'categories','2026-02-09 19:06:14','2026-02-09 19:06:14'),(18,'59345dc1-19f8-39c4-bebb-4b35c27b8b4b.png','png','593/59345dc1-19f8-39c4-bebb-4b35c27b8b4b.png',NULL,NULL,'categories','2026-02-09 19:27:40','2026-02-09 19:27:40'),(19,'075e3b7a-8c68-30e0-9ea8-4b4ec287f036.jpeg','jpeg','075/075e3b7a-8c68-30e0-9ea8-4b4ec287f036.jpeg',NULL,NULL,'questions','2026-02-09 19:27:40','2026-02-09 19:27:40'),(20,'f97321e4-a44d-3333-af2b-453e549ecbe0.jpg','jpg','f97/f97321e4-a44d-3333-af2b-453e549ecbe0.jpg',NULL,NULL,'categories','2026-02-09 19:27:40','2026-02-09 19:27:40'),(21,'f15f1e2f-f813-3fdf-bbe0-a3a859f54a3a.jpg','jpg','f15/f15f1e2f-f813-3fdf-bbe0-a3a859f54a3a.jpg',NULL,NULL,'questions','2026-02-09 19:27:40','2026-02-09 19:27:40'),(22,'18bddeb7-89f5-3c90-9534-6ec1097e9509.png','png','18b/18bddeb7-89f5-3c90-9534-6ec1097e9509.png',NULL,NULL,'categories','2026-02-09 19:27:40','2026-02-09 19:27:40'),(23,'6392e040-f782-361b-849c-33911b064cf0.png','png','639/6392e040-f782-361b-849c-33911b064cf0.png',NULL,NULL,'questions','2026-02-09 19:27:40','2026-02-09 19:27:40'),(24,'0228c8c8-0dc4-340e-921c-9046c2b46ce0.png','png','022/0228c8c8-0dc4-340e-921c-9046c2b46ce0.png',NULL,NULL,'categories','2026-02-09 19:27:40','2026-02-09 19:27:40'),(25,'b17b762a-7543-3c52-93ce-5728bcefe21d.png','png','b17/b17b762a-7543-3c52-93ce-5728bcefe21d.png',NULL,NULL,'questions','2026-02-09 19:27:40','2026-02-09 19:27:40'),(26,'68b3ecef-245f-3347-b554-689063e9baf6.jpeg','jpeg','68b/68b3ecef-245f-3347-b554-689063e9baf6.jpeg',NULL,NULL,'categories','2026-02-09 19:27:40','2026-02-09 19:27:40'),(27,'a785c51b-033f-3215-96e9-c2a987051606.jpg','jpg','a78/a785c51b-033f-3215-96e9-c2a987051606.jpg',NULL,NULL,'questions','2026-02-09 19:27:40','2026-02-09 19:27:40'),(28,'bc8371b2-7af2-3b60-8c98-32b54a62a5a5.jpeg','jpeg','bc8/bc8371b2-7af2-3b60-8c98-32b54a62a5a5.jpeg',NULL,NULL,'categories','2026-02-09 19:27:40','2026-02-09 19:27:40'),(29,'c335e633-10a8-36a1-9070-27a5025d7f03.jpg','jpg','c33/c335e633-10a8-36a1-9070-27a5025d7f03.jpg',NULL,NULL,'questions','2026-02-09 19:27:40','2026-02-09 19:27:40'),(30,'697b5439-2924-33ec-90dd-89932b66cc0b.jpeg','jpeg','697/697b5439-2924-33ec-90dd-89932b66cc0b.jpeg',NULL,NULL,'categories','2026-02-09 19:27:40','2026-02-09 19:27:40'),(31,'5df3766f-e8e3-3acf-a5c7-30d8b7f4a0e5.png','png','5df/5df3766f-e8e3-3acf-a5c7-30d8b7f4a0e5.png',NULL,NULL,'questions','2026-02-09 19:27:40','2026-02-09 19:27:40'),(32,'c86e487c-3760-3244-9efd-1874ea502035.jpeg','jpeg','c86/c86e487c-3760-3244-9efd-1874ea502035.jpeg',NULL,NULL,'categories','2026-02-09 19:27:40','2026-02-09 19:27:40'),(33,'68e293e3-c635-38e1-906b-e3bf515033ef.png','png','68e/68e293e3-c635-38e1-906b-e3bf515033ef.png',NULL,NULL,'questions','2026-02-09 19:27:40','2026-02-09 19:27:40'),(34,'3070e457-19e4-3965-9288-a4c79e7c1f0e.png','png','307/3070e457-19e4-3965-9288-a4c79e7c1f0e.png',NULL,NULL,'categories','2026-02-09 19:27:40','2026-02-09 19:27:40'),(35,'6d9edb0a-5f52-36ad-8905-fa7657e419f3.jpg','jpg','6d9/6d9edb0a-5f52-36ad-8905-fa7657e419f3.jpg',NULL,NULL,'questions','2026-02-09 19:27:40','2026-02-09 19:27:40'),(36,'48909ab3-1c40-3edd-8add-a83e3b8ea54f.jpeg','jpeg','489/48909ab3-1c40-3edd-8add-a83e3b8ea54f.jpeg',NULL,NULL,'categories','2026-02-09 19:27:40','2026-02-09 19:27:40'),(37,'a727354e-b51f-3e8b-b8e4-79dbe0d75423.jpg','jpg','a72/a727354e-b51f-3e8b-b8e4-79dbe0d75423.jpg',NULL,NULL,'questions','2026-02-09 19:27:40','2026-02-09 19:27:40');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'2024_04_15_074360_create_files_table',1),(4,'2024_04_15_074400_create_categories_table',1),(5,'2024_04_15_075201_create_questions_table',1),(6,'2024_04_15_080658_create_question_statistics_table',1),(7,'2024_04_15_081643_create_question_votes_table',2),(8,'2024_05_14_153225_create_comments_table',2),(9,'2024_05_14_155757_create_comment_votes_table',3),(10,'2024_05_14_165704_create_comments_replies_table',3),(11,'2024_07_08_081554_create_feedback_table',3),(12,'2025_02_19_190122_add_row_photo_to_users',3),(13,'2025_11_02_100258_create_settings_table',3),(14,'2026_01_07_135059_create_tags_table',3),(15,'2026_01_08_121505_create_question_tags_table',3),(16,'2026_01_21_104615_create_user_tags_table',3),(17,'2026_02_02_120724_create_notifications_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `entity` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` bigint unsigned NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'system',
  `viewed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `entity_id` (`entity_id`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_statistics`
--

DROP TABLE IF EXISTS `question_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_statistics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint unsigned NOT NULL,
  `views` bigint NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_statistics_question_idx` (`question_id`),
  CONSTRAINT `question_statistics_question_fk` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_statistics`
--

LOCK TABLES `question_statistics` WRITE;
/*!40000 ALTER TABLE `question_statistics` DISABLE KEYS */;
INSERT INTO `question_statistics` VALUES (1,1,0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(2,2,0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(3,3,0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(4,4,1,'2026-02-09 19:27:40','2026-02-10 08:25:42'),(5,5,0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(6,6,1,'2026-02-09 19:27:40','2026-02-10 08:41:09'),(7,7,0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(8,8,0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(9,9,0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(10,10,2,'2026-02-09 19:27:40','2026-02-10 09:24:26');
/*!40000 ALTER TABLE `question_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_tags`
--

DROP TABLE IF EXISTS `question_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_tags_question_id_index` (`question_id`),
  KEY `question_tags_tag_id_index` (`tag_id`),
  CONSTRAINT `question_tags_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `question_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_tags`
--

LOCK TABLES `question_tags` WRITE;
/*!40000 ALTER TABLE `question_tags` DISABLE KEYS */;
INSERT INTO `question_tags` VALUES (1,2,1,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(2,1,11,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(3,3,11,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(4,6,5,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(5,9,10,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(6,2,5,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(7,9,3,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(8,9,1,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(9,3,5,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(10,7,9,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(11,8,6,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(12,5,9,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(13,1,5,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(14,3,6,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(15,2,6,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(16,10,2,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(17,4,6,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(18,9,2,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(19,8,6,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(20,6,2,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(21,1,7,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(22,4,8,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(23,1,6,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(24,4,8,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(25,2,1,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(26,8,11,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(27,5,7,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(28,1,9,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(29,4,9,'2026-02-09 19:44:59','2026-02-09 19:44:59'),(30,10,7,'2026-02-09 19:44:59','2026-02-09 19:44:59');
/*!40000 ALTER TABLE `question_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question_votes`
--

DROP TABLE IF EXISTS `question_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_votes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `vote` tinyint NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `question_votes_question_idx` (`question_id`),
  KEY `question_votes_user_idx` (`user_id`),
  CONSTRAINT `question_votes_question_fk` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `question_votes_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_votes`
--

LOCK TABLES `question_votes` WRITE;
/*!40000 ALTER TABLE `question_votes` DISABLE KEYS */;
INSERT INTO `question_votes` VALUES (1,3,15,1,'2026-02-09 19:31:30','2026-02-09 19:31:30'),(2,10,7,-1,'2026-02-09 19:32:01','2026-02-09 19:32:01'),(3,5,5,-1,'2026-02-09 19:32:01','2026-02-09 19:32:01'),(4,4,21,1,'2026-02-09 19:32:01','2026-02-09 19:32:01'),(5,4,13,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(6,1,23,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(7,3,6,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(8,2,7,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(9,2,17,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(10,9,37,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(11,9,8,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(12,3,28,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(13,9,29,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(14,10,22,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(15,7,27,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(16,1,33,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(17,5,16,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(18,3,1,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(19,1,30,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(20,4,18,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(21,2,18,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(22,7,31,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(23,6,22,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(24,10,37,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(25,2,31,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(26,3,39,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(27,10,20,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(28,1,35,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(29,4,23,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(30,7,37,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(31,2,34,1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(32,4,38,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(33,3,7,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49'),(34,4,34,-1,'2026-02-09 19:40:49','2026-02-09 19:40:49');
/*!40000 ALTER TABLE `question_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `file_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `questions_code_unique` (`code`),
  KEY `questions_user_idx` (`user_id`),
  KEY `questions_category_idx` (`category_id`),
  KEY `questions_file_idx` (`file_id`),
  KEY `questions_title_idx` (`title`),
  CONSTRAINT `questions_category_fk` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `questions_file_fk` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE,
  CONSTRAINT `questions_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
INSERT INTO `questions` VALUES (1,6,10,19,'Deleniti hic sunt odit et sit.','deleniti-hic-sunt-odit-et-sit',0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(2,2,11,21,'Quam eius tempore doloremque ex voluptas.','quam-eius-tempore-doloremque-ex-voluptas',0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(3,10,12,23,'Sed omnis unde ipsa at inventore voluptas.','sed-omnis-unde-ipsa-at-inventore-voluptas',0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(4,4,13,25,'Eum nobis sequi doloribus officia vel doloribus eveniet.','eum-nobis-sequi-doloribus-officia-vel-doloribus-eveniet',1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(5,7,14,27,'Sint facilis maxime quis et.','sint-facilis-maxime-quis-et',0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(6,3,15,29,'Qui sit est error inventore architecto sint deleniti eaque.','qui-sit-est-error-inventore-architecto-sint-deleniti-eaque',1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(7,6,16,31,'Eos et accusantium est.','eos-et-accusantium-est',1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(8,2,17,33,'Expedita nobis et rerum corporis.','expedita-nobis-et-rerum-corporis',0,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(9,10,18,35,'Delectus quisquam eos et et omnis non ut.','delectus-quisquam-eos-et-et-omnis-non-ut',1,'2026-02-09 19:27:40','2026-02-09 19:27:40'),(10,4,19,37,'Dolorem officiis repellendus quis molestias assumenda sit.','dolorem-officiis-repellendus-quis-molestias-assumenda-sit',1,'2026-02-09 19:27:40','2026-02-09 19:27:40');
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `area` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'main',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort` smallint NOT NULL DEFAULT '300',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (1,'Аниме',300),(2,'Фильмы',300),(3,'Сериалы',300),(4,'Природа',300),(5,'Горы',300),(6,'Компьютерный игры',300),(7,'Игры',300),(8,'Недвижимость',300),(9,'Инвестиции',300),(10,'Техника',300),(11,'Политика',300);
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_tags`
--

DROP TABLE IF EXISTS `user_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_tags_user_id_index` (`user_id`),
  KEY `user_tags_tag_id_index` (`tag_id`),
  CONSTRAINT `user_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_tags_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_tags`
--

LOCK TABLES `user_tags` WRITE;
/*!40000 ALTER TABLE `user_tags` DISABLE KEYS */;
INSERT INTO `user_tags` VALUES (1,52,10,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(2,12,2,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(3,23,8,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(4,28,8,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(5,27,2,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(6,45,6,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(7,45,8,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(8,1,3,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(9,7,10,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(10,27,4,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(11,10,5,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(12,11,6,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(13,14,1,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(14,27,5,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(15,46,11,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(16,21,4,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(17,58,9,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(18,9,10,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(19,23,5,'2026-02-09 19:49:28','2026-02-09 19:49:28'),(20,9,5,'2026-02-09 19:49:28','2026-02-09 19:49:28');
/*!40000 ALTER TABLE `user_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `photo_id` bigint unsigned DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_photo_idx` (`photo_id`),
  CONSTRAINT `users_files_fk` FOREIGN KEY (`photo_id`) REFERENCES `files` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Юлия Дмитриевна Игнатова','user',0,NULL,'igor.nikiforova@example.net','2026-02-09 19:06:13','$2y$12$74JWG9X5Gnuxk09YZcQOfem0Ekaw9TBIOS1njPWLofU1n/y3xjcw6','s1szy4B0SD','2026-02-09 19:06:14','2026-02-09 19:06:14'),(2,'Шаров Викентий Владимирович','user',0,NULL,'wlarionov@example.org','2026-02-09 19:06:14','$2y$12$74JWG9X5Gnuxk09YZcQOfem0Ekaw9TBIOS1njPWLofU1n/y3xjcw6','CJE1Oxj0My','2026-02-09 19:06:14','2026-02-09 19:06:14'),(3,'Маргарита Романовна Архипова','user',0,NULL,'vsevolod.silina@example.net','2026-02-09 19:06:14','$2y$12$74JWG9X5Gnuxk09YZcQOfem0Ekaw9TBIOS1njPWLofU1n/y3xjcw6','QeJX2bhaW3','2026-02-09 19:06:14','2026-02-09 19:06:14'),(4,'Федосья Максимовна Соболева','user',0,NULL,'lavrentij50@example.net','2026-02-09 19:06:14','$2y$12$74JWG9X5Gnuxk09YZcQOfem0Ekaw9TBIOS1njPWLofU1n/y3xjcw6','fohcnRXyhZ','2026-02-09 19:06:14','2026-02-09 19:06:14'),(5,'Иннокентий Львович Буров','user',0,NULL,'fedoseeva.veniamin@example.net','2026-02-09 19:06:14','$2y$12$74JWG9X5Gnuxk09YZcQOfem0Ekaw9TBIOS1njPWLofU1n/y3xjcw6','NtfgcyY0Ed','2026-02-09 19:06:14','2026-02-09 19:06:14'),(6,'Кристина Александровна Александрова','user',0,NULL,'georgij.safonov@example.net','2026-02-09 19:06:14','$2y$12$74JWG9X5Gnuxk09YZcQOfem0Ekaw9TBIOS1njPWLofU1n/y3xjcw6','tmOPoZbNPC','2026-02-09 19:06:14','2026-02-09 19:06:14'),(7,'Регина Борисовна Копылова','user',0,NULL,'elvira93@example.org','2026-02-09 19:06:14','$2y$12$74JWG9X5Gnuxk09YZcQOfem0Ekaw9TBIOS1njPWLofU1n/y3xjcw6','Mz6mq6RKOQ','2026-02-09 19:06:14','2026-02-09 19:06:14'),(8,'Филатов Тарас Иванович','user',0,NULL,'rogov.vaceslav@example.net','2026-02-09 19:06:14','$2y$12$74JWG9X5Gnuxk09YZcQOfem0Ekaw9TBIOS1njPWLofU1n/y3xjcw6','2OCL4z94bS','2026-02-09 19:06:14','2026-02-09 19:06:14'),(9,'Раиса Александровна Филиппова','user',0,NULL,'oarhipova@example.org','2026-02-09 19:06:14','$2y$12$74JWG9X5Gnuxk09YZcQOfem0Ekaw9TBIOS1njPWLofU1n/y3xjcw6','1ICjaqQgy3','2026-02-09 19:06:14','2026-02-09 19:06:14'),(10,'Богдан Александрович Кириллов','user',0,NULL,'matveev.adam@example.net','2026-02-09 19:06:14','$2y$12$74JWG9X5Gnuxk09YZcQOfem0Ekaw9TBIOS1njPWLofU1n/y3xjcw6','S64RXA0I5g','2026-02-09 19:06:14','2026-02-09 19:06:14'),(11,'Молчанов Дан Александрович','user',0,NULL,'uknazeva@example.net','2026-02-09 19:31:30','$2y$12$rVedcxYRHT3SMTtsHe74tO6/WnYcklcS5i7Mtro4IUwlKKTamqE2G','ckTBBO8C9G','2026-02-09 19:31:30','2026-02-09 19:31:30'),(12,'Игнатий Львович Марков','user',0,NULL,'valentin.gorbaceva@example.org','2026-02-09 19:31:30','$2y$12$rVedcxYRHT3SMTtsHe74tO6/WnYcklcS5i7Mtro4IUwlKKTamqE2G','i7gJHnbwCJ','2026-02-09 19:31:30','2026-02-09 19:31:30'),(13,'Клавдия Романовна Тарасова','user',0,NULL,'knazev.dina@example.net','2026-02-09 19:31:30','$2y$12$rVedcxYRHT3SMTtsHe74tO6/WnYcklcS5i7Mtro4IUwlKKTamqE2G','ufxqk4vQDq','2026-02-09 19:31:30','2026-02-09 19:31:30'),(14,'Лидия Алексеевна Колобова','user',0,NULL,'klavdia.pahomov@example.com','2026-02-09 19:31:30','$2y$12$rVedcxYRHT3SMTtsHe74tO6/WnYcklcS5i7Mtro4IUwlKKTamqE2G','eOQv7WI2zq','2026-02-09 19:31:30','2026-02-09 19:31:30'),(15,'Борисова Альбина Борисовна','user',0,NULL,'koseleva.ignat@example.org','2026-02-09 19:31:30','$2y$12$rVedcxYRHT3SMTtsHe74tO6/WnYcklcS5i7Mtro4IUwlKKTamqE2G','lN1Ad2NBDp','2026-02-09 19:31:30','2026-02-09 19:31:30'),(16,'Ника Фёдоровна Афанасьева','user',0,NULL,'boleslav13@example.org','2026-02-09 19:31:30','$2y$12$rVedcxYRHT3SMTtsHe74tO6/WnYcklcS5i7Mtro4IUwlKKTamqE2G','VsnuwSRZ2m','2026-02-09 19:31:30','2026-02-09 19:31:30'),(17,'Ершов Лев Максимович','user',0,NULL,'bogdanov.garri@example.com','2026-02-09 19:31:30','$2y$12$rVedcxYRHT3SMTtsHe74tO6/WnYcklcS5i7Mtro4IUwlKKTamqE2G','hbqCzPoMf6','2026-02-09 19:31:30','2026-02-09 19:31:30'),(18,'Анастасия Ивановна Михайлова','user',0,NULL,'matveeva.gerasim@example.org','2026-02-09 19:31:30','$2y$12$rVedcxYRHT3SMTtsHe74tO6/WnYcklcS5i7Mtro4IUwlKKTamqE2G','U5mAE2v4P7','2026-02-09 19:31:30','2026-02-09 19:31:30'),(19,'Павел Евгеньевич Козлов','user',0,NULL,'anastasia.egorova@example.com','2026-02-09 19:31:30','$2y$12$rVedcxYRHT3SMTtsHe74tO6/WnYcklcS5i7Mtro4IUwlKKTamqE2G','3ZvXG2YF3l','2026-02-09 19:31:30','2026-02-09 19:31:30'),(20,'Пестов Максим Сергеевич','user',0,NULL,'kirill.miheeva@example.net','2026-02-09 19:31:30','$2y$12$rVedcxYRHT3SMTtsHe74tO6/WnYcklcS5i7Mtro4IUwlKKTamqE2G','D3ZXmCRMGB','2026-02-09 19:31:30','2026-02-09 19:31:30'),(21,'Жанна Евгеньевна Фадеева','user',0,NULL,'marta.samojlov@example.com','2026-02-09 19:32:00','$2y$12$qshqvEr7.G0fKFpl/WFAm.siHO5X/FJ8HEghBC8gt70gruJo3cCty','msCuUFBoPX','2026-02-09 19:32:00','2026-02-09 19:32:00'),(22,'Устинов Антонин Александрович','user',0,NULL,'tkabanov@example.com','2026-02-09 19:32:00','$2y$12$qshqvEr7.G0fKFpl/WFAm.siHO5X/FJ8HEghBC8gt70gruJo3cCty','GQgmuyZfQ8','2026-02-09 19:32:00','2026-02-09 19:32:00'),(23,'Самсонова Мария Евгеньевна','user',0,NULL,'izueva@example.com','2026-02-09 19:32:00','$2y$12$qshqvEr7.G0fKFpl/WFAm.siHO5X/FJ8HEghBC8gt70gruJo3cCty','orucmTLeuH','2026-02-09 19:32:00','2026-02-09 19:32:00'),(24,'Гавриил Фёдорович Якушев','user',0,NULL,'lavrentev.anatolij@example.net','2026-02-09 19:32:00','$2y$12$qshqvEr7.G0fKFpl/WFAm.siHO5X/FJ8HEghBC8gt70gruJo3cCty','aWsYX9gxxi','2026-02-09 19:32:00','2026-02-09 19:32:00'),(25,'Валентина Андреевна Тихонова','user',0,NULL,'nazar.rozkova@example.com','2026-02-09 19:32:00','$2y$12$qshqvEr7.G0fKFpl/WFAm.siHO5X/FJ8HEghBC8gt70gruJo3cCty','H21eJBh1sb','2026-02-09 19:32:00','2026-02-09 19:32:00'),(26,'Кондратьев Михаил Дмитриевич','user',0,NULL,'alena.kulakova@example.com','2026-02-09 19:32:00','$2y$12$qshqvEr7.G0fKFpl/WFAm.siHO5X/FJ8HEghBC8gt70gruJo3cCty','KKcPCGWRHA','2026-02-09 19:32:00','2026-02-09 19:32:00'),(27,'Красильников Михаил Александрович','user',0,NULL,'sarov.irina@example.org','2026-02-09 19:32:00','$2y$12$qshqvEr7.G0fKFpl/WFAm.siHO5X/FJ8HEghBC8gt70gruJo3cCty','g8RM6Ss9mq','2026-02-09 19:32:00','2026-02-09 19:32:00'),(28,'Рожкова Лада Романовна','user',0,NULL,'solovev.vitalij@example.net','2026-02-09 19:32:00','$2y$12$qshqvEr7.G0fKFpl/WFAm.siHO5X/FJ8HEghBC8gt70gruJo3cCty','WQxR3ei7Uc','2026-02-09 19:32:00','2026-02-09 19:32:00'),(29,'Ефим Александрович Бобров','user',0,NULL,'alisa.doronina@example.com','2026-02-09 19:32:00','$2y$12$qshqvEr7.G0fKFpl/WFAm.siHO5X/FJ8HEghBC8gt70gruJo3cCty','q8AF4Jnb7n','2026-02-09 19:32:00','2026-02-09 19:32:00'),(30,'Влад Романович Казаков','user',0,NULL,'konovalov.elizaveta@example.com','2026-02-09 19:32:00','$2y$12$qshqvEr7.G0fKFpl/WFAm.siHO5X/FJ8HEghBC8gt70gruJo3cCty','4FnObwV8qG','2026-02-09 19:32:00','2026-02-09 19:32:00'),(31,'Горбунов Даниил Дмитриевич','user',0,NULL,'akovleva.zinaida@example.com','2026-02-09 19:40:48','$2y$12$jDHZ2zTmJhdL7tWu/PAA0erCAnw/9wnyOC8.AMibA7hOwHZ.8n69m','wTwmvd5EA9','2026-02-09 19:40:48','2026-02-09 19:40:48'),(32,'Якушев Вениамин Владимирович','user',0,NULL,'marina65@example.org','2026-02-09 19:40:48','$2y$12$jDHZ2zTmJhdL7tWu/PAA0erCAnw/9wnyOC8.AMibA7hOwHZ.8n69m','i9nhrYsTSR','2026-02-09 19:40:48','2026-02-09 19:40:48'),(33,'Быкова Эмма Александровна','user',0,NULL,'oisakova@example.net','2026-02-09 19:40:48','$2y$12$jDHZ2zTmJhdL7tWu/PAA0erCAnw/9wnyOC8.AMibA7hOwHZ.8n69m','b1g2PhMZAH','2026-02-09 19:40:48','2026-02-09 19:40:48'),(34,'Беляков Даниил Фёдорович','user',0,NULL,'anzelika42@example.com','2026-02-09 19:40:48','$2y$12$jDHZ2zTmJhdL7tWu/PAA0erCAnw/9wnyOC8.AMibA7hOwHZ.8n69m','Dx2g8TLZij','2026-02-09 19:40:48','2026-02-09 19:40:48'),(35,'Нестор Сергеевич Самойлов','user',0,NULL,'avdeev.eduard@example.org','2026-02-09 19:40:48','$2y$12$jDHZ2zTmJhdL7tWu/PAA0erCAnw/9wnyOC8.AMibA7hOwHZ.8n69m','eINVd8tkCG','2026-02-09 19:40:48','2026-02-09 19:40:48'),(36,'Исаева Ольга Андреевна','user',0,NULL,'komissarova.emma@example.org','2026-02-09 19:40:48','$2y$12$jDHZ2zTmJhdL7tWu/PAA0erCAnw/9wnyOC8.AMibA7hOwHZ.8n69m','DvrE2dqLAv','2026-02-09 19:40:48','2026-02-09 19:40:48'),(37,'Зимин Никита Борисович','user',0,NULL,'zanna33@example.net','2026-02-09 19:40:48','$2y$12$jDHZ2zTmJhdL7tWu/PAA0erCAnw/9wnyOC8.AMibA7hOwHZ.8n69m','jD77DqiRfA','2026-02-09 19:40:48','2026-02-09 19:40:48'),(38,'Исаков Аркадий Романович','user',0,NULL,'ndavydova@example.org','2026-02-09 19:40:48','$2y$12$jDHZ2zTmJhdL7tWu/PAA0erCAnw/9wnyOC8.AMibA7hOwHZ.8n69m','C4H6KdEP63','2026-02-09 19:40:48','2026-02-09 19:40:48'),(39,'Гавриил Борисович Мясников','user',0,NULL,'inna07@example.org','2026-02-09 19:40:48','$2y$12$jDHZ2zTmJhdL7tWu/PAA0erCAnw/9wnyOC8.AMibA7hOwHZ.8n69m','zn20odNHmS','2026-02-09 19:40:48','2026-02-09 19:40:48'),(40,'Субботина Нонна Максимовна','user',0,NULL,'akim.hohlov@example.net','2026-02-09 19:40:48','$2y$12$jDHZ2zTmJhdL7tWu/PAA0erCAnw/9wnyOC8.AMibA7hOwHZ.8n69m','bIJ7axhghq','2026-02-09 19:40:48','2026-02-09 19:40:48'),(41,'Колесникова Федосья Андреевна','user',0,NULL,'egorova.sofia@example.org','2026-02-09 19:42:39','$2y$12$GPo4UocdD4MNWqju.lLy9.qv2tXXL6.93desz7iqsyL4k4k0kFL2i','yILdSFDoPb','2026-02-09 19:42:40','2026-02-09 19:42:40'),(42,'Кошелев Борис Борисович','user',0,NULL,'zinaida.alekseev@example.org','2026-02-09 19:42:40','$2y$12$GPo4UocdD4MNWqju.lLy9.qv2tXXL6.93desz7iqsyL4k4k0kFL2i','zV2B8dUWXO','2026-02-09 19:42:40','2026-02-09 19:42:40'),(43,'Терентьева Алиса Дмитриевна','user',0,NULL,'qzaharova@example.com','2026-02-09 19:42:40','$2y$12$GPo4UocdD4MNWqju.lLy9.qv2tXXL6.93desz7iqsyL4k4k0kFL2i','Mw0rXtghZR','2026-02-09 19:42:40','2026-02-09 19:42:40'),(44,'Лазарев Никодим Фёдорович','user',0,NULL,'ravdeeva@example.org','2026-02-09 19:42:40','$2y$12$GPo4UocdD4MNWqju.lLy9.qv2tXXL6.93desz7iqsyL4k4k0kFL2i','TUa4VI6TSq','2026-02-09 19:42:40','2026-02-09 19:42:40'),(45,'Вадим Андреевич Игнатьев','user',0,NULL,'golubev.nonna@example.com','2026-02-09 19:42:40','$2y$12$GPo4UocdD4MNWqju.lLy9.qv2tXXL6.93desz7iqsyL4k4k0kFL2i','AIrHzW4oFf','2026-02-09 19:42:40','2026-02-09 19:42:40'),(46,'Рада Андреевна Панова','user',0,NULL,'konstantin.melnikov@example.org','2026-02-09 19:42:40','$2y$12$GPo4UocdD4MNWqju.lLy9.qv2tXXL6.93desz7iqsyL4k4k0kFL2i','e0fSVUQQKn','2026-02-09 19:42:40','2026-02-09 19:42:40'),(47,'Шубин Сергей Иванович','user',0,NULL,'tatana.samsonova@example.org','2026-02-09 19:42:40','$2y$12$GPo4UocdD4MNWqju.lLy9.qv2tXXL6.93desz7iqsyL4k4k0kFL2i','56imgXDZKE','2026-02-09 19:42:40','2026-02-09 19:42:40'),(48,'Альбина Максимовна Шубина','user',0,NULL,'sokolova.akov@example.com','2026-02-09 19:42:40','$2y$12$GPo4UocdD4MNWqju.lLy9.qv2tXXL6.93desz7iqsyL4k4k0kFL2i','34c61T08NG','2026-02-09 19:42:40','2026-02-09 19:42:40'),(49,'Блохина Вера Андреевна','user',0,NULL,'varvara02@example.org','2026-02-09 19:42:40','$2y$12$GPo4UocdD4MNWqju.lLy9.qv2tXXL6.93desz7iqsyL4k4k0kFL2i','ZTpkCtIkBw','2026-02-09 19:42:40','2026-02-09 19:42:40'),(50,'Нестеров Тимофей Андреевич','user',0,NULL,'taisia.filippova@example.org','2026-02-09 19:42:40','$2y$12$GPo4UocdD4MNWqju.lLy9.qv2tXXL6.93desz7iqsyL4k4k0kFL2i','3bUdlR86Er','2026-02-09 19:42:40','2026-02-09 19:42:40'),(51,'Фомичёва Людмила Алексеевна','user',0,NULL,'oksana.dorofeeva@example.com','2026-02-09 19:44:58','$2y$12$S4rZ0DmzhcmztUXT8jiki.eZw4lHvbsPmaXlvuqCo341auPDC6/VG','wQtVlgDtPa','2026-02-09 19:44:58','2026-02-09 19:44:58'),(52,'Данилов Денис Сергеевич','user',0,NULL,'anzelika05@example.org','2026-02-09 19:44:58','$2y$12$S4rZ0DmzhcmztUXT8jiki.eZw4lHvbsPmaXlvuqCo341auPDC6/VG','Dc1sGUB7vO','2026-02-09 19:44:58','2026-02-09 19:44:58'),(53,'Потапов Никодим Иванович','user',0,NULL,'antonin.mamontova@example.org','2026-02-09 19:44:58','$2y$12$S4rZ0DmzhcmztUXT8jiki.eZw4lHvbsPmaXlvuqCo341auPDC6/VG','Eni5b6BmhB','2026-02-09 19:44:58','2026-02-09 19:44:58'),(54,'Мухин Владимир Иванович','user',0,NULL,'markova.klementina@example.com','2026-02-09 19:44:58','$2y$12$S4rZ0DmzhcmztUXT8jiki.eZw4lHvbsPmaXlvuqCo341auPDC6/VG','yXl3LCZUaJ','2026-02-09 19:44:58','2026-02-09 19:44:58'),(55,'Трофимов Лев Алексеевич','user',0,NULL,'masnikova.lada@example.org','2026-02-09 19:44:58','$2y$12$S4rZ0DmzhcmztUXT8jiki.eZw4lHvbsPmaXlvuqCo341auPDC6/VG','mHLUZXa9yL','2026-02-09 19:44:58','2026-02-09 19:44:58'),(56,'Крылов Данила Владимирович','user',0,NULL,'belousov.adrian@example.net','2026-02-09 19:44:58','$2y$12$S4rZ0DmzhcmztUXT8jiki.eZw4lHvbsPmaXlvuqCo341auPDC6/VG','S4TsDEuWsx','2026-02-09 19:44:58','2026-02-09 19:44:58'),(57,'Доронин Абрам Борисович','user',0,NULL,'jgordeeva@example.com','2026-02-09 19:44:58','$2y$12$S4rZ0DmzhcmztUXT8jiki.eZw4lHvbsPmaXlvuqCo341auPDC6/VG','PfdJUUeEnf','2026-02-09 19:44:58','2026-02-09 19:44:58'),(58,'Прохорова Валентина Владимировна','user',0,NULL,'fedoseev.evgenia@example.net','2026-02-09 19:44:58','$2y$12$S4rZ0DmzhcmztUXT8jiki.eZw4lHvbsPmaXlvuqCo341auPDC6/VG','EqXBU5SiIQ','2026-02-09 19:44:58','2026-02-09 19:44:58'),(59,'Фёдоров Юлий Фёдорович','user',0,NULL,'zuev.zahar@example.org','2026-02-09 19:44:58','$2y$12$S4rZ0DmzhcmztUXT8jiki.eZw4lHvbsPmaXlvuqCo341auPDC6/VG','UnhQQs2Gvs','2026-02-09 19:44:58','2026-02-09 19:44:58'),(60,'Иммануил Алексеевич Моисеев','user',0,NULL,'ignat92@example.com','2026-02-09 19:44:58','$2y$12$S4rZ0DmzhcmztUXT8jiki.eZw4lHvbsPmaXlvuqCo341auPDC6/VG','Iw9SfFkSrc','2026-02-09 19:44:58','2026-02-09 19:44:58'),(61,'igor','admin',0,NULL,'gustavforeli@gmail.com',NULL,'$2y$12$wN7AHo2szdKFABwj3lpN5upW1wAL77fwtxvyKyI3LeyI4M5FU6hGm',NULL,'2026-02-10 09:00:26','2026-02-10 09:00:26');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-10  9:31:04
